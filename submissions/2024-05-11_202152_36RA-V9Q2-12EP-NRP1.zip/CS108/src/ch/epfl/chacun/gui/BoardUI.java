package ch.epfl.chacun.gui;

import ch.epfl.chacun.*;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.ScrollPane;
import javafx.scene.effect.Blend;
import javafx.scene.effect.BlendMode;
import javafx.scene.effect.ColorInput;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * Represents the GUI for the board
 * @author Antoine Bastide (375407)
 */
public class BoardUI {
    /** The map containing all the previously generated images */
    private static final Map<Integer, Image> cachedImages = createEmptyImageMap();
    /** The map containing all the previously generated occupants */
    private static final Map<Occupant, Node> cachedOccupants = new HashMap<>();
    /** The map containing all the previously generated animal markers */
    private static final Map<Animal, Node> cachedMarkers = new HashMap<>();
    /** The map containing all the generated veils */
    private static final Map<Color, ColorInput> cachedVeilColors = createVeilColors();
    /** The map containing all the previously generated veils */
    private static final Map<Group, Blend> cachedVeils = new HashMap<>();

    /**
     * Used to create the empty image map
     * @return The map containing the empty image
     */
    private static Map<Integer, Image> createEmptyImageMap() {
        Map<Integer, Image> map = new HashMap<>();
        WritableImage emptyTileImage = new WritableImage(1, 1);
        emptyTileImage.getPixelWriter().setColor(0, 0, Color.gray(0.98));
        map.put(-1, emptyTileImage);
        return map;
    }

    /**
     * Used to create the veil colors
     * @return The map containing all the veil colors
     */
    private static Map<Color, ColorInput> createVeilColors() {
        Map<Color, ColorInput> map = new HashMap<>();
        Set<Color> colors = PlayerColor.ALL.stream().map(ColorMap::fillColor).collect(Collectors.toSet());
        colors.addAll(Set.of(Color.BLACK, Color.WHITE));
        for (Color color : colors) {
            ColorInput input = new ColorInput(0, 0, 1, 1, color);
            input.setWidth(ImageLoader.NORMAL_TILE_FIT_SIZE);
            input.setHeight(ImageLoader.NORMAL_TILE_FIT_SIZE);
            map.put(color, input);
        }
        return map;
    }

    /** Private constructor to prevent instantiation */
    private BoardUI() {}

    /**
     * Used to create the GUI for the board
     * @param reach The reach of the board
     * @param gameState The current game state
     * @param tileRotation The current tile rotation
     * @param visibleOccupants The visible occupants
     * @param tilesInEvidence The ids of the tiles in evidence
     * @param rotateTile The function to rotate the tile
     * @param placeTile The function to place the tile
     * @param selectOccupant The function to select an occupant
     * @return The GUI for the board
     */
    public static Node create(int reach, ObservableValue<GameState> gameState, ObservableValue<Rotation> tileRotation,
                              ObservableValue<Set<Occupant>> visibleOccupants, ObservableValue<Set<Integer>> tilesInEvidence,
                              Consumer<Rotation> rotateTile, Consumer<Pos> placeTile, Consumer<Occupant> selectOccupant) {
        // Create the grid and scroll pane
        GridPane grid = new GridPane();
        ScrollPane scrollPane = new ScrollPane(grid);

        // Apply the stylesheet and ids
        scrollPane.getStylesheets().add("board.css");
        scrollPane.setId("board-scroll-pane");
        grid.setId("board-grid");

        // Create the groups for the tiles and occupants
        for (int i = -reach; i <= reach; i++) {
            for (int j = -reach; j <= reach; j++) {
                // Create the tile group and image view
                ImageView tileView = new ImageView();
                tileView.setFitWidth(ImageLoader.NORMAL_TILE_FIT_SIZE);
                tileView.setFitHeight(ImageLoader.NORMAL_TILE_FIT_SIZE);

                Group tileGroup = new Group(tileView);
                Pos pos = new Pos(i, j);

                ObservableValue<PlacedTile> placedTile = gameState.map(s -> s.board().tileAt(pos));
                ObservableValue<Tile> tile = gameState.map(GameState::tileToPlace);
                ObservableValue<Boolean> isInsertionPosition = gameState.map(s -> s.board().insertionPositions()).map(p -> p.contains(pos));
                ObservableValue<Boolean> hoverProperty = tileGroup.hoverProperty();

                ObjectBinding<CellData> cellData = Bindings.createObjectBinding(() -> {
                    // Create the helper variables
                    PlayerColor currentPlayer = gameState.getValue().currentPlayer();
                    boolean nextActionIsCorrect = gameState.getValue().nextAction() == GameState.Action.PLACE_TILE;
                    boolean groupHasTile = Objects.nonNull(placedTile.getValue());

                    // Get the color of the cell
                    Color color = Color.TRANSPARENT;
                    // If the tile is not in evidence, show it as black
                    if (!tilesInEvidence.getValue().isEmpty()) {
                        if (groupHasTile && !tilesInEvidence.getValue().contains(placedTile.getValue().id()))
                            color = Color.BLACK;
                    }
                    // If the group has no tile and is in the insertion positions, try and show the fringe
                    if (!groupHasTile && nextActionIsCorrect && isInsertionPosition.getValue()) {
                        // If the tile is not hovered show the fringe
                        if (!hoverProperty.getValue())
                            color = ColorMap.fillColor(Objects.requireNonNull(currentPlayer));
                        // If the tile is hovered and cannot be placed, white it out
                        else {
                            PlacedTile pt = new PlacedTile(tile.getValue(), currentPlayer, tileRotation.getValue(), pos);
                            color = gameState.getValue().board().canAddTile(pt) ? Color.TRANSPARENT : Color.WHITE;
                        }
                    }

                    // Find the image
                    Image image;
                    boolean correctVeil = color != Color.BLACK;
                    // Reset the tile view to the correct tile if needed
                    if (groupHasTile) image = cachedImages.computeIfAbsent(placedTile.getValue().id(),
                                _ -> ImageLoader.normalImageForTile(placedTile.getValue().tile()));
                    // Set the tile view to the next tile
                    else if (tilesInEvidence.getValue().isEmpty() && nextActionIsCorrect && correctVeil &&
                            hoverProperty.getValue() && Objects.nonNull(tile) && isInsertionPosition.getValue())
                        image = cachedImages.computeIfAbsent(tile.getValue().id(), _ ->
                                ImageLoader.normalImageForTile(tile.getValue()));
                    // Reset the tile view to the empty tile
                    else image = cachedImages.get(-1);

                    return new CellData(image, tileRotation.getValue(), color);
                }, placedTile, tilesInEvidence, tileRotation, hoverProperty, isInsertionPosition, tile);

                // Bind the veil color
                tileGroup.effectProperty().bind(cellData.map(CellData::color).map(c -> c == Color.TRANSPARENT ? null :
                    cachedVeils.computeIfAbsent(tileGroup, _ -> {
                            Blend blend = new Blend(BlendMode.SRC_OVER);
                            blend.setOpacity(0.5);
                            blend.topInputProperty().bind(cellData.map(CellData::color).map(cachedVeilColors::get));
                            return blend;
                    })
                ));

                // Bind the image and rotation
                tileView.imageProperty().bind(cellData.map(CellData::image));
                tileGroup.rotateProperty().bind(cellData.map(d -> d.rotation.degreesCW()));

                placedTile.addListener((o, oldValue, newValue) -> {
                    if (Objects.isNull(newValue) || newValue.equals(oldValue)) return;
                    // Update the animal markers and occupants if the tile exists and has changed

                    // Create the animal UI if needed
                    for (Zone.Meadow z : newValue.meadowZones()) {
                        for (Animal animal : z.animals()) {
                            cachedMarkers.computeIfAbsent(animal, _ -> {
                                ImageView imageView = new ImageView();
                                imageView.setFitHeight(ImageLoader.MARKER_FIT_SIZE);
                                imageView.setFitWidth(ImageLoader.MARKER_FIT_SIZE);
                                imageView.setId(STR."marker_\{animal.id()}");
                                imageView.getStyleClass().add("marker");

                                imageView.visibleProperty().bind(o.map(_ -> gameState.getValue().board().cancelledAnimals().contains(animal)));
                                tileGroup.getChildren().add(imageView);

                                return imageView;
                            });
                        }
                    }

                    // Create the occupant UI if needed, and cache it
                    for (Occupant occupant : newValue.potentialOccupants()) {
                        cachedOccupants.computeIfAbsent(occupant, _ -> {
                            // Create the occupant view
                            Node occupantView = Icon.newFor(newValue.placer(), occupant);
                            occupantView.setId(STR."\{occupant.kind().toString().toLowerCase()}_\{occupant.zoneId()}");
                            occupantView.setRotate(tileRotation.getValue().negated().degreesCW());

                            // Handle the click event
                            occupantView.setOnMouseClicked(e -> {
                                if (e.getButton() == MouseButton.PRIMARY) selectOccupant.accept(occupant);
                            });
                            occupantView.rotateProperty().bind(tileGroup.rotateProperty().negate());
                            occupantView.visibleProperty().bind(visibleOccupants.map(s -> s.contains(occupant)));
                            tileGroup.getChildren().add(occupantView);

                            return occupantView;
                        });
                    }
                    tileGroup.rotateProperty().unbind();
                });

                tileGroup.setOnMouseClicked(e -> {
                    // Check if we are in the right state to place the tile and if the position is valid
                    if (gameState.getValue().nextAction() != GameState.Action.PLACE_TILE ||
                            !gameState.getValue().board().insertionPositions().contains(pos))
                        return;

                    // Place the tile on left click and rotate it on right-click
                    if (e.getButton() == MouseButton.PRIMARY) placeTile.accept(pos);
                    else if (e.getButton() == MouseButton.SECONDARY) {
                        if (e.isAltDown()) rotateTile.accept(Rotation.RIGHT);
                        else rotateTile.accept(Rotation.LEFT);
                    }
                });

                grid.add(tileGroup, i + reach, j + reach);
            }
        }

        // Call the center method
        Platform.runLater(() -> centerScrollPaneOnGroup(grid, scrollPane, reach, reach));

        return scrollPane;
    }

    /**
     * Used to center the scroll pane on a given group
     * @param grid The grid containing the group
     * @param scrollPane The scroll pane to center
     * @param colIndex The column index of the group
     * @param rowIndex The row index of the group
     */
    private static void centerScrollPaneOnGroup(GridPane grid, ScrollPane scrollPane, int colIndex, int rowIndex) {
        // Assuming each tile and the group have the same size
        double tileWidth = ImageLoader.NORMAL_TILE_FIT_SIZE;
        double tileHeight = ImageLoader.NORMAL_TILE_FIT_SIZE;

        // Calculate the center positions of the tile in the viewport
        double centerX = colIndex * tileWidth + tileWidth / 2;
        double centerY = rowIndex * tileHeight + tileHeight / 2;

        // Calculate the percentage of the scrollPane's total content width and height
        double hValue = centerX / grid.getWidth();
        double vValue = centerY / grid.getHeight();

        // Adjust the scroll values
        scrollPane.setHvalue(hValue);
        scrollPane.setVvalue(vValue);
    }

    /**
     * Represents the data of a cell
     * @param image The image of the cell
     * @param rotation The rotation of the image
     * @param color The color of the cell
     */
    private record CellData(Image image, Rotation rotation, Color color) {}
}
