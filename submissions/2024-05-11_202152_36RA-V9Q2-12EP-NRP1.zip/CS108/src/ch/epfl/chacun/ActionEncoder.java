package ch.epfl.chacun;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/**
 * Used to encode, decode actions' parameters and apply these actions to a game state
 * @author Adam BEKKAR (379476)
 */
public class ActionEncoder {
    /** Private constructor to prevent instantiation */
    private ActionEncoder() {}

    /**
     * Used to get a StateAction of a game state that is placing a tile
     * @param gameState The game state to get the encoded action from
     * @param placedTile The placed tile to encode
     * @return The StateAction of the game state that is placing a tile
     * @throws IllegalArgumentException If the placed tile is not on an insertion position
     */
    public static StateAction withPlacedTile(GameState gameState, PlacedTile placedTile) {
        Preconditions.checkArgument(Objects.nonNull(placedTile)
                && gameState.board().insertionPositions().contains(placedTile.pos()));

        // Sort the insertion positions by x and then by y
        List<Pos> sortedPos = gameState.board().insertionPositions().stream()
                .sorted(Comparator.comparingInt(Pos::x).thenComparingInt(Pos::y))
                .toList();

        // Get the index of the placed tile in the sorted list of insertion positions
        char index = (char) sortedPos.indexOf(placedTile.pos());
        // Get the rotation of the placed tile
        char rotation = (char) placedTile.rotation().ordinal();

        // Return the new game state with the placed tile and the encoded action
        return new StateAction(gameState.withPlacedTile(placedTile),
                Base32.encodeBits10((index & 0xff) << 2 | rotation & 0x3));
    }

    /**
     * Used to get a StateAction of a game state that is removing a tile
     * @param gameState The game state to get the encoded action from
     * @param occupant The occupant to remove
     * @return The StateAction of the game state that is removing a tile
     */
    public static StateAction withNewOccupant(GameState gameState, Occupant occupant) {
        // Check if the occupant can be placed on the last tile and get the encoded action
        // and return the new game state with the new occupant and the encoded action
        if (Objects.isNull(occupant)) return new StateAction(gameState.withNewOccupant(null), Base32.encodeBits5(0x1f));
        return new StateAction(gameState.withNewOccupant(occupant),
                Base32.encodeBits5((occupant.kind().ordinal() & 0x1) << 4 | Zone.localId(occupant.zoneId()) & 0xf));
    }

    /**
     * Used to get a StateAction of a game state that is removing an occupant
     * @param gameState The game state to get the encoded action from
     * @param occupant The occupant to remove
     * @return The StateAction of the game state that is removing an occupant
     * @throws IllegalArgumentException If the occupant is not a pawn
     */
    public static StateAction withOccupantRemoved(GameState gameState, Occupant occupant) {
        // Sort the occupants on the board by zone id
        List<Occupant> onBoardOccupants = gameState.board().occupants().stream()
                .sorted(Comparator.comparingInt(Occupant::zoneId))
                .toList();
        // Check if the occupant is on the board and get the encoded action
        // and return the new game state with the occupant removed and the encoded action
        return new StateAction(gameState.withOccupantRemoved(occupant), Base32.encodeBits5(
                Objects.nonNull(occupant) && onBoardOccupants.contains(occupant) && occupant.kind() == Occupant.Kind.PAWN ?
                        onBoardOccupants.indexOf(occupant) : 0x1f));
    }

    /**
     * Used to decode and apply an action to a game state
     * @param gameState The game state to apply the action to
     * @param action The action to decode and apply
     * @return The new game state after decoding and applying the action
     * or null if the action is not valid
     */
    public static StateAction decodeAndApply(GameState gameState, String action) {
        try {
            return decoderAndApplier(gameState, action);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Used to decode and apply an action to a game state
     * This method needs to be used in the {@link #decodeAndApply(GameState, String)}} method only
     * @param gameState The game state to apply the action to
     * @param action The action to decode and apply
     * @return The new game state after decoding and applying the action
     * @throws IllegalArgumentException If the action is not valid or not compatible with the game state
     */
    private static StateAction decoderAndApplier(GameState gameState, String action) {
        Preconditions.checkArgument(Base32.isValid(action) && gameState.nextAction() != GameState.Action.START_GAME
                && gameState.nextAction() != GameState.Action.END_GAME);
        int actionCode = Base32.decode(action);

        return switch (gameState.nextAction()) {
            case PLACE_TILE -> {
                // Check if the action is valid and get the rotation and the position of the placed tile
                int rCode = actionCode & 0x3;
                int pCode = actionCode >> 2;
                Preconditions.checkArgument(action.length() == 2 && 0 <= pCode && pCode < 190);

                Rotation rotation = Rotation.values()[rCode];
                Pos pos = gameState.board().insertionPositions().stream()
                        .sorted(Comparator.comparingInt(Pos::x).thenComparingInt(Pos::y))
                        .toList().get(pCode);
                // Return the state action with the new game state and the action
                PlacedTile placedTile = new PlacedTile(gameState.tileToPlace(), gameState.currentPlayer(), rotation, pos);
                yield new StateAction(gameState.withPlacedTile(placedTile), action);
            }
            case OCCUPY_TILE -> {
                if (actionCode == 0x1f) yield new StateAction(gameState.withNewOccupant(null), action);
                int kCode = (actionCode >> 4) & 1;
                int zCode = actionCode & 0xf;

                // Check if the action is valid and get the kind and the zone id of the new occupant
                Preconditions.checkArgument(action.length() == 1 && zCode < 10);
                Occupant.Kind kind = (kCode == 0 ? Occupant.Kind.PAWN : Occupant.Kind.HUT);

                for (Occupant o : gameState.lastTilePotentialOccupants())
                    if (Zone.localId(o.zoneId()) == Zone.localId(zCode) && o.kind() == kind)
                        // Return the state action with the new game state and the action
                        yield new StateAction(gameState.withNewOccupant(o), action);
                throw new IllegalArgumentException();
            }
            case RETAKE_PAWN -> {
                if (actionCode == 0x1f) yield new StateAction(gameState.withOccupantRemoved(null), action);
                // Check if the action is valid and get the zone id of the pawn to remove
                Preconditions.checkArgument(action.length() == 1 && 0 <= actionCode && actionCode < 25);
                Occupant occupant = gameState.board().occupants().stream()
                        .sorted(Comparator.comparingInt(Occupant::zoneId))
                        .toList().get(actionCode);

                // Return the state action with the new game state and the action
                yield new StateAction(gameState.withOccupantRemoved(occupant), action);
            }
            // If the action is START_GAME or END_GAME, throw an exception
            default -> throw new IllegalArgumentException();
        };
    }

    /**
     * Represents a pair of a game state and an encoded action in Base32
     * @param gameState The game state after applying the action
     * @param action Code of the action applied to the game state in Base32
     */
    public record StateAction(GameState gameState, String action) {}
}
