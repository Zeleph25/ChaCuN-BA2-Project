package ch.epfl.chacun;

import java.util.*;

/**
 * Represents the board of the game
 * @author Adam BEKKAR (379476)
 * @author Antoine Bastide (375407)
 */
public final class Board {
    /** The number of tiles per row */
    private static final int TILES_PER_ROW = 25;
    /** The total number of tiles on the board */
    private static final int TOTAL_TILE_COUNT = TILES_PER_ROW * TILES_PER_ROW;
    /** The number of tiles that separate the center of the board from one edge */
    public static final int REACH = 12;
    /** The empty board */
    public static final Board EMPTY = new Board(
            new PlacedTile[TOTAL_TILE_COUNT], new int[0], new ZonePartitions(
            new ZonePartition<>(), new ZonePartition<>(), new ZonePartition<>(), new ZonePartition<>()
    ), new HashSet<>());

    /** The placed tiles on the board */
    private final PlacedTile[] placedTiles;
    /** The index of the placed tile in the placedTiles array in the order in which it has been placed */
    private final int[] placedTilesIndex;
    /** The zone partitions of the board */
    private final ZonePartitions zonePartitions;
    /** The cancelled animals of the board */
    private final Set<Animal> cancelledAnimals;
    
    /**
     * Constructs a board with the given placed tiles, placed tiles index, zone partitions and cancelled animals
     * @param placedTiles The placed tiles of the board
     * @param placedTilesIndex The index of the placed tile in the placedTiles array in the order in which it has been placed
     * @param zonePartitions The zone partitions of the board
     * @param cancelledAnimals The cancelled animals of the board
     */
    private Board(PlacedTile[] placedTiles, int[] placedTilesIndex, ZonePartitions zonePartitions, Set<Animal> cancelledAnimals) {
        this.placedTiles = placedTiles;
        this.placedTilesIndex = placedTilesIndex;
        this.zonePartitions = zonePartitions;
        this.cancelledAnimals = Collections.unmodifiableSet(cancelledAnimals);
    }

    /**
     * Used to return the placed tile at the given position
     * @param pos the position of the tile to find
     * @return the placed tile at the given position or null if there is none or the position is out of the board
     */
    public PlacedTile tileAt(Pos pos) {
        int index = index(pos);
        return index < TOTAL_TILE_COUNT && index > -1 && index < placedTiles.length ? placedTiles[index] : null;
    }

    /**
     * Used to return the placed tile given its id
     * @param tileId the id of the tile to find
     * @return the placed tile with the given id
     * @throws IllegalArgumentException if the tile is not on the board
     */
    public PlacedTile tileWithId(int tileId) {
        for (int index : placedTilesIndex) {
            if (placedTiles[index].id() == tileId) return placedTiles[index];
        }
        throw new IllegalArgumentException();
    }

    /**
     * Used to return the set of the cancelled animals of the board
     * @return the set of the cancelled animals of the board
     */
    public Set<Animal> cancelledAnimals() {
        return cancelledAnimals;
    }

    /**
     * Used to return the set of all the occupants of the board
     * @return the set of all the occupants of the board
     */
    public Set<Occupant> occupants() {
        Set<Occupant> occupants = new HashSet<>();
        for (int index : placedTilesIndex) {
            if (placedTiles[index].occupant() != null) occupants.add(placedTiles[index].occupant());
        }
        return occupants;
    }

    /**
     * Used to return the forest area containing the given forest zone
     * @param forest the forest zone to find the area for
     * @throws IllegalArgumentException if the forest zone is not on the board
     * @return the area containing the forest zone
     */
    public Area<Zone.Forest> forestArea(Zone.Forest forest) {
        return zonePartitions.forests().areas().stream()
                .filter(area -> area.zones().contains(forest)).findFirst().orElseThrow(IllegalArgumentException::new);
    }

    /**
     * Used to return the meadow area containing the given meadow zone
     * @param meadow the meadow zone to find the area for
     * @return the area containing the meadow zone
     * @throws IllegalArgumentException if the meadow zone is not on the board
     */
    public Area<Zone.Meadow> meadowArea(Zone.Meadow meadow) {
        return zonePartitions.meadows().areas().stream()
                .filter(area -> area.zones().contains(meadow)).findFirst().orElseThrow(IllegalArgumentException::new);
    }

    /**
     * Used to return the river area containing the given river zone
     * @param riverZone the river zone to find the area for
     * @return the area containing the river zone
     * @throws IllegalArgumentException if the river zone is not on the board
     */
    public Area<Zone.River> riverArea(Zone.River riverZone) {
        return zonePartitions.rivers().areas().stream()
                .filter(area -> area.zones().contains(riverZone)).findFirst().orElseThrow(IllegalArgumentException::new);
    }

    /**
     * Used to return the river system area containing the given river system zone
     * @param water the river system zone to find the area for
     * @return the area containing the river system zone
     * @throws IllegalArgumentException if the river system zone is not on the board
     */
    public Area<Zone.Water> riverSystemArea(Zone.Water water) {
        return zonePartitions.riverSystems().areas().stream()
                .filter(area -> area.zones().contains(water)).findFirst().orElseThrow(IllegalArgumentException::new);
    }

    /**
     * Used to return the set of all the meadow areas of the board
     * @return the set of all the meadow areas of the board
     */
    public Set<Area<Zone.Meadow>> meadowAreas() {
        return Set.copyOf(zonePartitions.meadows().areas());
    }

    /**
     * Used to return the set of all the river systems areas of the board
     * @return the set of all the river systems areas of the board
     */
    public Set<Area<Zone.Water>> riverSystemAreas() {
        return Set.copyOf(zonePartitions.riverSystems().areas());
    }

    /**
     * Used to return the adjacent meadow area to the given zone of the given position
     * @param pos the position to find the adjacent meadow area for
     * @param meadowZone the meadow zone to find the adjacent meadow area for
     * @return the adjacent meadow area to the given zone of the given position
     */
    public Area<Zone.Meadow> adjacentMeadow(Pos pos, Zone.Meadow meadowZone) {
        Set<Zone.Meadow> adjacentMeadows = new HashSet<>();

        // Iterate through the 8 adjacent tiles
        for (int dx = -1; dx < 2 ; dx++) {
            for (int dy = -1; dy < 2 ; dy++) {
                PlacedTile placedTile = tileAt(new Pos(pos.x() + dx, pos.y() + dy));
                if (placedTile == null) continue;

                // Add all the meadow zones of the adjacent tiles to the set adjacentMeadows
                for (Zone zone : placedTile.tile().zones()) {
                    if (zone instanceof Zone.Meadow meadow) adjacentMeadows.add(meadow);
                }
            }
        }

        Set<Zone.Meadow> meadowSet = new HashSet<>();
        Set<PlayerColor> occupants = new HashSet<>();

        // Iterate through all the meadow areas of the board
        for (Area<Zone.Meadow> meadowArea : zonePartitions.meadows().areas()) {
            if (meadowArea.zones().contains(meadowZone)) {
                meadowSet.addAll(meadowArea.zones());
                occupants.addAll(meadowArea.occupants());
            }
        }

        // Retain only the intersecting meadow zones
        meadowSet.retainAll(adjacentMeadows);

        return new Area<>(meadowSet, List.copyOf(occupants), 0);
    }

    /**
     * Used to return the number of occupants of the given kind of the given player
     * @param player the player to find the number of occupants for
     * @param occupantKind the kind of the occupant to find the number of
     * @return the number of occupants of the given kind of the given player
     */
    public int occupantCount(PlayerColor player, Occupant.Kind occupantKind) {
        int count = 0;
        for (int index : placedTilesIndex) {
            if (placedTiles[index].placer() != null && placedTiles[index].placer() == player
                    && placedTiles[index].occupant() != null && placedTiles[index].occupant().kind() == occupantKind)
               count++;
        }
        return count;
    }

    /**
     * Used to return the set of the positions where a tile can be inserted
     * @return the set of the positions where a tile can be inserted
     */
    public Set<Pos> insertionPositions() {
        Set<Pos> insertPositions = new HashSet<>();

        // For each placed tile, if a neighbor tile isn't placed yet, then add it to insertPositions
        for (int index : placedTilesIndex) {
            if (placedTiles[index] != null) {
                for (Direction d : Direction.ALL) {
                    Pos neighbourPos = placedTiles[index].pos().neighbor(d);
                    if (tileAt(neighbourPos) == null) insertPositions.add(neighbourPos);
                }
            }
        }

        return insertPositions;
    }

    /** Used to return the last placed tile of the board or null if there is none */
    public PlacedTile lastPlacedTile() {
        return placedTilesIndex.length == 0 ? null : placedTiles[placedTilesIndex[placedTilesIndex.length - 1]];
    }

    /**
     * Used to return the set of the forests closed by the last placed tile
     * @return the set of the forests closed by the last placed tile
     */
    public Set<Area<Zone.Forest>> forestsClosedByLastTile() {
        Set<Area<Zone.Forest>> closedForests = new HashSet<>();
        if (placedTilesIndex.length == 0) return closedForests;

        PlacedTile lastPlacedTile = lastPlacedTile();
        if (lastPlacedTile == null) return Set.of();

        for (Zone.Forest forest : lastPlacedTile.forestZones()) {
            Area<Zone.Forest> area = forestArea(forest);
            if (area.isClosed()) closedForests.add(area);
        }
        return closedForests;
    }

    /**
     * Used to return the set of the rivers closed by the last placed tile
     * @return the set of the rivers closed by the last placed tile
     */
    public Set<Area<Zone.River>> riversClosedByLastTile() {
        Set<Area<Zone.River>> closedRivers = new HashSet<>();
        if (placedTilesIndex.length == 0) return closedRivers;

        PlacedTile lastPlacedTile = lastPlacedTile();
        if (lastPlacedTile == null) return Set.of();

        for (Zone.River river : lastPlacedTile.riverZones()) {
            Area<Zone.River> area = riverArea(river);
            if (area.isClosed()) closedRivers.add(area);
        }
        return closedRivers;
    }

    /**
     * Used to indicate if the given tile can be added to the board
     * @param tile the tile to add to the board
     * @return true if the given tile can be added to the board, false otherwise
     */
    public boolean canAddTile(PlacedTile tile) {
        if (insertionPositions().contains(tile.pos())) {
            for (Direction d : Direction.ALL) {
                // If the tile cannot be placed next to the neighbour, return false
                PlacedTile neighbour = tileAt(tile.pos().neighbor(d));
                if (neighbour != null && !neighbour.side(d.opposite()).isSameKindAs(tile.side(d))) return false;
            }
            return true;
        }
        return false;
    }

    /**
     * Used to indicate if the given tile can be placed on the board with an eventual rotation
     * @param tile the tile to place on the board
     * @return true if the given tile can be placed on the board with an eventual rotation, false otherwise
     */
    public boolean couldPlaceTile(Tile tile) {
        for (Pos pos : insertionPositions()) {
            // Rotate the tile and check if it can be added to the board
            for (Rotation rotation : Rotation.ALL) {
                PlacedTile placedTile = new PlacedTile(tile, PlayerColor.RED, rotation, pos);
                if (canAddTile(placedTile)) return true;
            }
        }
        return false;
    }

    /**
     * Used to return a new board with the given tile added to it
     * @param tile the tile to add to the board
     * @return a new board with the given tile added to it
     * @throws IllegalArgumentException if the tile is not empty and cannot be added to the board
     */
    public Board withNewTile(PlacedTile tile) {
        Preconditions.checkArgument(placedTilesIndex.length == 0 || canAddTile(tile));

        // Inside the placedTiles array, add the new placed tile and update the placedTilesIndex array
        PlacedTile[] newPlacedTiles = Arrays.copyOf(placedTiles, placedTiles.length);
        int[] newPlacedTilesIndex = Arrays.copyOf(placedTilesIndex, placedTilesIndex.length + 1);

        // Index of the new placed tile in the placedTiles array
        int placedTileIndex = index(tile.pos());

        newPlacedTilesIndex[newPlacedTilesIndex.length - 1] = placedTileIndex;
        newPlacedTiles[placedTileIndex] = tile;

        // Inside the zone partitions, add the new tile
        ZonePartitions.Builder newZonePartitions = new ZonePartitions.Builder(zonePartitions);
        newZonePartitions.addTile(tile.tile());

        for (Direction d : Direction.ALL) {
            PlacedTile neighbour = tileAt(tile.pos().neighbor(d));
            if (neighbour != null && neighbour.side(d.opposite()).isSameKindAs(tile.side(d)))
                // Connect the sides of the new tile with the sides of its neighbours
                newZonePartitions.connectSides(tile.side(d), neighbour.side(d.opposite()));
        }

        return new Board(newPlacedTiles, newPlacedTilesIndex, newZonePartitions.build(), cancelledAnimals);
    }

    /**
     * Used to return a board like this one but with the given occupant added to it
     * @param occupant the occupant to add to the board
     * @return a board like this one but with the given occupant added to it
     * @throws IllegalArgumentException if the tile occupied by the given occupant is not on the board
     */
    public Board withOccupant(Occupant occupant) {
        int tileId = Zone.tileId(occupant.zoneId());
        Preconditions.checkArgument(tileWithId(tileId).occupant() == null);
        PlacedTile placedTile = tileWithId(tileId).withOccupant(occupant);

        // Inside the placedTiles array, replace the unoccupied placed tile
        // by a new placed tile with the given occupant added to it
        PlacedTile[] newPlacedTiles = Arrays.copyOf(placedTiles, placedTiles.length);
        newPlacedTiles[index(placedTile.pos())] = placedTile;

        // Inside the zone partitions, add the pawn
        ZonePartitions.Builder newZonePartitions = new ZonePartitions.Builder(zonePartitions);
        for (Zone zone : placedTile.tile().zones()) {
            if (zone.id() == occupant.zoneId())  {

                newZonePartitions.addInitialOccupant(placedTile.placer(), occupant.kind(), zone);
                break;
            }
        }

        return new Board(newPlacedTiles, placedTilesIndex, newZonePartitions.build(), cancelledAnimals);
    }

    /**
     * Used to remove a certain occupant from the board
     * @param occupant the occupant to remove from the board
     * @return A new board without the given occupant
     */
    public Board withoutOccupant(Occupant occupant) {
        int tileId = Zone.tileId(occupant.zoneId());
        PlacedTile placedTile = tileWithId(tileId);

        // Inside the placedTiles array, replace the tile that has the given occupant
        // by a new placed tile without any occupant
        PlacedTile[] newPlacedTiles = Arrays.copyOf(placedTiles, placedTiles.length);
        newPlacedTiles[index(placedTile.withNoOccupant().pos())] = placedTile.withNoOccupant();

        // // Inside the zone partitions, remove the pawn
        ZonePartitions.Builder newZonePartitions = new ZonePartitions.Builder(zonePartitions);
        for (Zone zone : placedTile.tile().zones()) {
            if (zone.id() == occupant.zoneId())  {
                newZonePartitions.removePawn(placedTile.placer(), zone);
                break;
            }
        }
        return new Board(newPlacedTiles, placedTilesIndex, newZonePartitions.build(), cancelledAnimals);
    }

    /**
     * Used to return a new board with the gatherers and fishers of the given forests and rivers removed
     * @param forests The forests to remove the gatherers of
     * @param rivers The rivers to remove the fishers of
     * @return A new board with the gatherers and fishers of the given forests and rivers removed
     */
    public Board withoutGatherersOrFishersIn(Set<Area<Zone.Forest>> forests, Set<Area<Zone.River>> rivers) {
        ZonePartitions.Builder newZonePartitions = new ZonePartitions.Builder(zonePartitions);
        PlacedTile[] newPlacedTiles = Arrays.copyOf(placedTiles, placedTiles.length);

        // Remove the gatherers from the given forests
        for (Area<Zone.Forest> forest : forests) {
           for (int id : forest.tileIds()) {
                PlacedTile placedTile = tileWithId(id);
                Occupant occupant = placedTile.occupant();

                if (occupant == null) continue;
                newPlacedTiles[id] = placedTile.withNoOccupant();
           }
            newZonePartitions.clearGatherers(forest);
        }

        // Remove the fishers from the given rivers
        for (Area<Zone.River> river : rivers) {
            for (int id : river.tileIds()) {
                PlacedTile placedTile = tileWithId(id);
                Occupant occupant = placedTile.occupant();

                if (occupant == null) continue;
                newPlacedTiles[id] = placedTile.withNoOccupant();
            }
            newZonePartitions.clearFishers(river);
        }

        return new Board(newPlacedTiles, placedTilesIndex, newZonePartitions.build(), cancelledAnimals);
    }

    /**
     * Used to return a new board with the given animals added to the cancelled animals of the board
     * @param newlyCancelledAnimals The newly cancelled animals to add to the board
     * @return A new board with the newly cancelled animals added to the cancelled animals of the board
     */
    public Board withMoreCancelledAnimals(Set<Animal> newlyCancelledAnimals) {
        Set<Animal> newCancelledAnimals = new HashSet<>(cancelledAnimals);
        newCancelledAnimals.addAll(newlyCancelledAnimals);
        return new Board(placedTiles, placedTilesIndex, zonePartitions, newCancelledAnimals);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) return false;
        else if (o == this) return true;
        else if (!(o instanceof Board board)) return false;
        else return Arrays.equals(placedTiles, board.placedTiles) && Arrays.equals(placedTilesIndex, board.placedTilesIndex)
                && zonePartitions.equals(board.zonePartitions) && cancelledAnimals.equals(board.cancelledAnimals);
    }

    @Override
    public int hashCode() {
        return Objects.hash(Arrays.hashCode(placedTiles), Arrays.hashCode(placedTilesIndex), zonePartitions, cancelledAnimals);
    }

    /**
     * Used to return the index of the placed tile in the placedTiles array
     * @param pos the position of the placed tile
     * @return the index of the placed tile in the placedTiles array
     */
    private int index(Pos pos) {
        return TILES_PER_ROW * (REACH + pos.y()) + REACH + pos.x();
    }

    /**
     * Used to return the non-null neighbours of the given position
     * @param pos the position to find the neighbours for
     * @return the non-null neighbours of the given position
     */
    private List<Pos> neighbours(Pos pos) {
        List<Pos> neighbours = new ArrayList<>();
        for (Direction d : Direction.ALL) {
            Pos neighbourPos = pos.neighbor(d);
            if (tileAt(neighbourPos) != null) neighbours.add(neighbourPos);
        }
        return neighbours;
    }
}