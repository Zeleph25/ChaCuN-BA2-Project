package ch.epfl.chacun;

/**
 * A utility class containing one static method to check the validity of arguments.
 * @author Adam BEKKAR (379476)
 */
public final class Preconditions {
    /** Private constructor to prevent instantiation */
    private Preconditions() {}

    /**
     * Checks if the given boolean is true.
     * @param shouldBeTrue The boolean to check
     * @throws IllegalArgumentException If the condition is not met
     */
    public static void checkArgument(boolean shouldBeTrue) {
        if (!shouldBeTrue) throw new IllegalArgumentException();
    }
}
