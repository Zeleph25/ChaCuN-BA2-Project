package ch.epfl.chacun;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Represents a tile that can be placed on the board.
 * @param id The id of the tile
 * @param kind The kind of the tile
 * @param n The north side of the tile
 * @param e The east side of the tile
 * @param s The south side of the tile
 * @param w The west side of the tile
 * @author Adam BEKKAR (379476)
 */
public record Tile(int id, Kind kind, TileSide n, TileSide e, TileSide s, TileSide w) {
    /** The different types of tiles that can be placed during the game */
    public enum Kind { START, NORMAL, MENHIR }

    /**
     * Used to get the sides of the tile in an unmodifiable list in the order n, e, s, w
     * @return the sides of the tile in the order n, e, s, w
     */
    public List<TileSide> sides() {
        return List.of(n, e, s, w);
    }

    /**
     * Used to get the zones of this tile touching its sides
     * @return the zones of this tile touching its sides
     */
    public Set<Zone> sideZones() {
        Set<Zone> zones = new HashSet<>();
        for (TileSide tileSide : sides()) {
            for (Zone zone : tileSide.zones()) {
                if (!(zone instanceof Zone.Lake)) zones.add(zone);
            }
        }
        return zones;
    }

    /**
     * Used to get the zones of the tile, lakes included
     * @return the zones of the tile, lakes included
     */
    public Set<Zone> zones() {
        Set<Zone> zones = new HashSet<>(sideZones());
        for (Zone zone : sideZones()) {
            if (zone instanceof Zone.River river && river.hasLake()) zones.add(river.lake());
        }
        return zones;
    }
}