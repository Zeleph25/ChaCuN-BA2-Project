package ch.epfl.chacun;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Used to represent the state of the game at a given moment
 * @param players The list of players in the game in the order they play, with the first player being the current player
 * @param tileDecks The decks of tiles available to the players
 * @param tileToPlace The tile to place on the board, or null if no tile is currently being placed
 * @param board The board containing the tiles and occupants placed on it
 * @param nextAction The next action to be taken by the current player
 * @param messageBoard The message board containing the messages displayed to the players up to this point
 * @author Antoine Bastide (375407)
 * @author Adam Bekkar (379476)
 */
public record GameState(List<PlayerColor> players, TileDecks tileDecks, Tile tileToPlace, Board board, Action nextAction, MessageBoard messageBoard) {
    public GameState {
        Preconditions.checkArgument(players.size() > 1);
        Preconditions.checkArgument(Objects.isNull(tileToPlace) ^ nextAction == Action.PLACE_TILE);
        Preconditions.checkArgument(Objects.nonNull(tileDecks) && Objects.nonNull(board)
                && Objects.nonNull(nextAction) && Objects.nonNull(messageBoard));
        players = List.copyOf(players);
    }

    /** Represents the next action to be taken by the current player */
    public enum Action { START_GAME, PLACE_TILE, OCCUPY_TILE, RETAKE_PAWN, END_GAME }

    /**
     * Used to get the initial state of the game
     * @param players The list of players in the game in the order they play,
     *                with the first player being the current player
     * @param tileDecks The decks of tiles available to the players
     * @param textMaker The text maker used to generate the messages
     * @return The initial state of the game
     */
    public static GameState initial(List<PlayerColor> players, TileDecks tileDecks, TextMaker textMaker) {
        return new GameState(players, tileDecks, null, Board.EMPTY, Action.START_GAME, new MessageBoard(textMaker, List.of()));
    }

    /**
     * Used to get the player that is currently playing
     * @return The player that is currently playing, or null if the next action is START_GAME or END_GAME
     */
    public PlayerColor currentPlayer() {
        return nextAction == Action.START_GAME || nextAction == Action.END_GAME ? null : players.getFirst();
    }

    /**
     * Used to get the number of free occupants of a given kind that a player can place on the board
     * @param player The player for which to get the number of free occupants
     * @param kind The kind of occupant for which to get the number of free occupants
     * @return The number of free occupants of the given kind that the player can place on the board
     */
    public int freeOccupantsCount(PlayerColor player, Occupant.Kind kind) {
        return Occupant.occupantsCount(kind) - board.occupantCount(player, kind);
    }

    /**
     * Used to get the set of potential occupants of the last placed tile
     * @return The set of potential occupants of the last placed tile
     * @throws IllegalArgumentException If no tile has been placed yet
     */
    public Set<Occupant> lastTilePotentialOccupants() {
        Preconditions.checkArgument(Objects.nonNull(board.lastPlacedTile()));
        if (Objects.nonNull(board.lastPlacedTile().occupant())) return Set.of();
        Set<Occupant> potentialOccupants =  board.lastPlacedTile().potentialOccupants();
        if (freeOccupantsCount(currentPlayer(), Occupant.Kind.PAWN) == 0)
            potentialOccupants = potentialOccupants.stream().filter(o -> o.kind() != Occupant.Kind.PAWN).collect(Collectors.toSet());
        if (freeOccupantsCount(currentPlayer(), Occupant.Kind.HUT) == 0)
            potentialOccupants = potentialOccupants.stream().filter(o -> o.kind() != Occupant.Kind.HUT).collect(Collectors.toSet());
        return potentialOccupants;
    }

    /**
     * Used to place the starting tile of the game on the board and start the game
     * @return The new state of the game with the starting tile placed
     * @throws IllegalArgumentException If the next action is not START_GAME
     */
    public GameState withStartingTilePlaced() {
        Preconditions.checkArgument(nextAction == Action.START_GAME);
        Board newBoard = board.withNewTile(new PlacedTile(tileDecks.topTile(Tile.Kind.START), null, Rotation.NONE, Pos.ORIGIN));
        Tile tile = tileDecks.topTile(Tile.Kind.NORMAL);
        return new GameState(players, tileDecks.withTopTileDrawn(Tile.Kind.START).withTopTileDrawn(Tile.Kind.NORMAL), tile,
                newBoard, Action.PLACE_TILE, messageBoard);
    }

    /**
     * Used to place a tile on the board
     * @param placedTile The tile to place on the board
     * @return The new state of the game with the tile placed
     * @throws IllegalArgumentException If the next action is not PLACE_TILE
     */
    public GameState withPlacedTile(PlacedTile placedTile) {
        Preconditions.checkArgument(nextAction == Action.PLACE_TILE && Objects.isNull(placedTile.occupant()));

        // Update the board, the message board and the tile decks
        Board newBoard = board.withNewTile(placedTile);
        MessageBoard newMessageBoard = messageBoard;

        // Check if the placed tile has special powers
        Zone spZone = placedTile.specialPowerZone();
        if (Objects.nonNull(spZone)) {
            switch (spZone.specialPower()) {
                // Score the log-boat
                case LOGBOAT -> newMessageBoard = newMessageBoard.withScoredLogboat(currentPlayer(),
                        newBoard.riverSystemArea((Zone.Water) spZone));
                // Score the hunting trap and remove the animals
                case HUNTING_TRAP -> {
                    // Find the meadows adjacent to the meadow where the hunting trap is placed and the animals in them
                    Area<Zone.Meadow> adjacentMeadows = newBoard.adjacentMeadow(placedTile.pos(), (Zone.Meadow) spZone);
                    Set<Animal> animals = Area.animals(adjacentMeadows, newBoard.cancelledAnimals());
                    Set<Animal> animalsToCancel = animalsToCancel(adjacentMeadows, newBoard, false, null, null);
                    // Cancel the animals in the meadows and score the hunting trap
                    newBoard = newBoard.withMoreCancelledAnimals(animalsToCancel);
                    newMessageBoard = newMessageBoard.withScoredHuntingTrap(currentPlayer(), adjacentMeadows);
                    newBoard = newBoard.withMoreCancelledAnimals(animals);
                }
                case SHAMAN -> {
                    if (canUseShamanPower(placedTile))
                        return new GameState(players, tileDecks, null, newBoard, Action.RETAKE_PAWN, newMessageBoard);
                }
            }
        }

        // Check if the player can occupy a tile, or tally the points at the end of the turn
        if (canOccupyTile(placedTile)) return new GameState(players, tileDecks, null, newBoard, Action.OCCUPY_TILE, newMessageBoard);
        else return tallyTurnPoints(newBoard, newMessageBoard, tileDecks);
    }

    /**
     * Used to retake a pawn on the board
     * @param occupant The occupant to remove from the board
     * @return The new state of the game with the occupant removed
     * @throws IllegalArgumentException If the next action is not RETAKE_PAWN
     */
    public GameState withOccupantRemoved(Occupant occupant) {
        // Check the arguments and update the board
        Preconditions.checkArgument(nextAction == Action.RETAKE_PAWN &&
                (Objects.isNull(occupant) || occupant.kind() == Occupant.Kind.PAWN));
        Board newBoard = Objects.nonNull(occupant) ? board.withoutOccupant(occupant) : board;

        // Check if the player can occupy a tile, or tally the points at the end of the turn
        if (canOccupyTile(newBoard.lastPlacedTile()))
            return new GameState(players, tileDecks, null, newBoard, Action.OCCUPY_TILE, messageBoard);
        else return tallyTurnPoints(newBoard, messageBoard, tileDecks);
    }

    /**
     * Used to occupy a tile on the board
     * @param occupant The occupant to place on the board
     * @return The new state of the game with the occupant placed
     * @throws IllegalArgumentException If the next action is not OCCUPY_TILE
     */
    public GameState withNewOccupant(Occupant occupant) {
        Preconditions.checkArgument(nextAction == Action.OCCUPY_TILE);
        Board newBoard = Objects.isNull(occupant) ? board : board.withOccupant(occupant);
        return tallyTurnPoints(newBoard, messageBoard, tileDecks);
    }

    /**
     * Used to check if a tile can be occupied
     * @return True if the tile can be occupied, false otherwise
     */
    private boolean canOccupyTile(PlacedTile placedTile) {
        Preconditions.checkArgument(Objects.nonNull(placedTile));
        // Do not allow the player to occupy a tile if there are no free occupants
        Set<Occupant> pawns = placedTile.potentialOccupants().stream().filter(o -> o.kind() == Occupant.Kind.PAWN)
                .collect(Collectors.toSet());
        Set<Occupant> huts = placedTile.potentialOccupants().stream().filter(o -> o.kind() == Occupant.Kind.HUT)
                .collect(Collectors.toSet());

        return (!pawns.isEmpty() && freeOccupantsCount(currentPlayer(), Occupant.Kind.PAWN) > 0)
                || (!huts.isEmpty() && freeOccupantsCount(currentPlayer(), Occupant.Kind.HUT) > 0);
    }

    /**
     * Used to check if a given tile has closed a menhir forest
     * @return True if the tile has closed a menhir forest, false otherwise
     */
    private boolean hasClosedMenhirForest(Board newBoard, TileDecks newTileDecks) {
        Set<Area<Zone.Forest>> closedForests = newBoard.forestsClosedByLastTile();
        PlacedTile placedTile = newBoard.lastPlacedTile();
        return Objects.nonNull(placedTile) && placedTile.kind() == Tile.Kind.NORMAL
                && newTileDecks.deckSize(Tile.Kind.MENHIR) > 0
                && !closedForests.isEmpty() && closedForests.stream().anyMatch(Area::hasMenhir);
    }

    /**
     * Used to check if a given tile can use the shaman power
     * @param placedTile The tile to check if it can use the shaman power
     * @return True if the tile can use the shaman power, false otherwise
     */
    private boolean canUseShamanPower(PlacedTile placedTile) {
        return Objects.nonNull(placedTile.specialPowerZone()) && Objects.nonNull(placedTile.specialPowerZone().specialPower())
                && placedTile.specialPowerZone().specialPower() == Zone.SpecialPower.SHAMAN
                && freeOccupantsCount(currentPlayer(), Occupant.Kind.PAWN) < Occupant.occupantsCount(Occupant.Kind.PAWN);
    }

    /**
     * Used to cancel the animals in a meadow area
     * @param meadowArea The meadow area in which to cancel the animals
     * @param newBoard The current state of the board
     * @param hasWildFire True if the meadow area has a wildfire, false otherwise
     * @return The set of animals to cancel in the meadow area
     */
    private Set<Animal> animalsToCancel(Area<Zone.Meadow> meadowArea, Board newBoard, boolean hasWildFire, Zone.Meadow pitTrapZone, Pos pos) {
        // Count all the deer and tigers in the meadows
        Set<Animal> animals = Area.animals(meadowArea, newBoard.cancelledAnimals());
        int tigerCount = (int) animals.stream().filter(animal -> animal.kind() == Animal.Kind.TIGER).count();
        int deerCount = (int) animals.stream().filter(animal -> animal.kind() == Animal.Kind.DEER).count();
        // If there are no tigers or deer in the adjacent meadows, return an empty set
        if (tigerCount == 0) return Set.of();

        // Find all the tigers
        Set<Animal> animalsToCancel = animals.stream().filter(a -> a.kind() == Animal.Kind.TIGER).collect(Collectors.toSet());
        // If there are no deer or the meadow has a wildfire, cancel all the tigers
        if (!hasWildFire && deerCount > 0) {
            // Find all the deer
            Set<Animal> deerToCancel = animals.stream().filter(a -> a.kind() == Animal.Kind.DEER).collect(Collectors.toSet());

            // Check for a pit trap
            if (Objects.nonNull(pitTrapZone) && deerCount >= tigerCount) {
                // Find the tile ids that are adjacent to the pit trap
                Set<Integer> tileIds = meadowArea.zones().stream()
                        .filter(zone -> !newBoard.adjacentMeadow(pos, pitTrapZone).zones().contains(zone))
                        .map(Zone::tileId)
                        .collect(Collectors.toSet());

                // Find the deer to keep, i.e. the ones that are in the adjacent meadows
                // The number of deer to keep is deerCount - tigerCount, since deerCount >= tigerCount
                Set<Animal> deerToKeep = deerToCancel.stream().filter(d -> !tileIds.contains(d.tileId()))
                        .limit(deerCount - tigerCount)
                        .collect(Collectors.toSet());

                // Find the deer to remove
                deerToCancel.removeAll(deerToKeep);
            }

            // Remove the correct number of deer from the animals to remove
            animalsToCancel.removeAll(deerToCancel.stream().limit(Math.min(tigerCount, deerCount)).collect(Collectors.toSet()));
        }
        return animalsToCancel;
    }

    /**
     * Used to tally the points at the end of a player's turn
     * @param newBoard The new state of the board
     * @param newMessageBoard The new state of the message board
     * @param newTileDecks The new state of the tile decks
     * @return The new state of the game after tallying the points
     */
    private GameState tallyTurnPoints(Board newBoard, MessageBoard newMessageBoard, TileDecks newTileDecks) {
        newTileDecks = newTileDecks.withTopTileDrawnUntil(Tile.Kind.NORMAL, newBoard::couldPlaceTile)
                .withTopTileDrawnUntil(Tile.Kind.MENHIR, newBoard::couldPlaceTile);

        Set<Area<Zone.Forest>> lastClosedForests = newBoard.forestsClosedByLastTile();
        Set<Area<Zone.River>> lastClosedRivers = newBoard.riversClosedByLastTile();

        // Check if the player has closed a forest
        for (Area<Zone.Forest> forestArea : lastClosedForests)
            newMessageBoard = newMessageBoard.withScoredForest(forestArea);
        // Check if the player has closed a river
        for (Area<Zone.River> riverArea : lastClosedRivers)
            newMessageBoard = newMessageBoard.withScoredRiver(riverArea);

        // Remove the gatherers and fishers from the closed forests and rivers
        newBoard = newBoard.withoutGatherersOrFishersIn(lastClosedForests, lastClosedRivers);

        // If the placed tile has closed a menhir forest, the player can place another tile
        if (hasClosedMenhirForest(newBoard, newTileDecks)) {
            // Assign the points to the player that has closed the menhir forest
            for (Area<Zone.Forest> forestArea : lastClosedForests)
                if (Area.hasMenhir(forestArea))
                    newMessageBoard = newMessageBoard.withClosedForestWithMenhir(currentPlayer(), forestArea);
            Tile tile = newTileDecks.topTile(Tile.Kind.MENHIR);
            return new GameState(players, newTileDecks.withTopTileDrawn(Tile.Kind.MENHIR), tile, newBoard, Action.PLACE_TILE, newMessageBoard);
        }
        // If there are no more tiles, tally the final scores
        else if (newTileDecks.deckSize(Tile.Kind.NORMAL) == 0) return tallyFinalScores(newBoard, newMessageBoard, newTileDecks);
        else {
            Tile tile = newTileDecks.topTile(Tile.Kind.NORMAL);
            return new GameState(new ArrayList<>(players.subList(1, players.size())) {{
                add(players.getFirst());
            }}, newTileDecks.withTopTileDrawn(Tile.Kind.NORMAL), tile, newBoard, Action.PLACE_TILE, newMessageBoard);
        }
    }

    /**
     * Used to tally the final scores at the end of the game
     * @param newBoard The new state of the board
     * @param newMessageBoard The new state of the message board
     * @param newTileDecks The new state of the tile decks
     * @return The new state of the game after tallying the final scores
     */
    private GameState tallyFinalScores(Board newBoard, MessageBoard newMessageBoard, TileDecks newTileDecks) {
        PlacedTile lastTile = newBoard.lastPlacedTile();
        Preconditions.checkArgument(Objects.nonNull(lastTile));
        // Tally the scores for the meadows
        for (Area<Zone.Meadow> meadowArea : newBoard.meadowAreas()) {
            // Check if the meadow has a wildfire or a pit trap
            boolean hasWildFire = meadowArea.zones().stream().anyMatch(zone -> zone.specialPower() == Zone.SpecialPower.WILD_FIRE);
            Zone.Meadow pitTrapZone = meadowArea.zones().stream().filter(zone -> zone.specialPower() == Zone.SpecialPower.PIT_TRAP)
                    .findFirst()
                    .orElse(null);

            Set<Animal> animalsToCancel = animalsToCancel(meadowArea, newBoard, hasWildFire, pitTrapZone, lastTile.pos());
            // Cancel the tigers in the meadow if it has a wildfire
            if (hasWildFire) {
                newMessageBoard = newMessageBoard.withScoredMeadow(meadowArea, animalsToCancel);
                newBoard = newBoard.withMoreCancelledAnimals(animalsToCancel);
            }
            // Cancel the deer and tigers in the meadow if it has a pit trap
            else if (Objects.nonNull(pitTrapZone)) {
                newBoard = newBoard.withMoreCancelledAnimals(animalsToCancel);
                newMessageBoard = newMessageBoard.withScoredPitTrap(meadowArea, newBoard.cancelledAnimals());
            }
            else newBoard = newBoard.withMoreCancelledAnimals(animalsToCancel);
        }

        // Tally the scores for the river systems
        for (Area<Zone.Water> riverSystemArea : newBoard.riverSystemAreas()) {
            boolean hasRaft = riverSystemArea.zones().stream().anyMatch(zone -> zone.specialPower() == Zone.SpecialPower.RAFT);
            if (hasRaft) newMessageBoard = newMessageBoard.withScoredRaft(riverSystemArea);
            newMessageBoard = newMessageBoard.withScoredRiverSystem(riverSystemArea);
        }

        // Find the winners
        Map<PlayerColor, Integer> results = newMessageBoard.points();
        int maxScore = results.values().stream().max(Integer::compare).orElseThrow();
        Set<PlayerColor> winners = results.entrySet().stream().filter(e -> e.getValue() == maxScore)
                .map(Map.Entry::getKey)
                .collect(Collectors.toSet());
        newMessageBoard = newMessageBoard.withWinners(winners, maxScore);

        return new GameState(players, newTileDecks, null, newBoard, Action.END_GAME, newMessageBoard);
    }
}