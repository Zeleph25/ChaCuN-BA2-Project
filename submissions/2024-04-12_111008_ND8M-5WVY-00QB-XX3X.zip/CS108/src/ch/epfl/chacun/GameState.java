package ch.epfl.chacun;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Represents the state of the game at a given moment
 * @param players The list of players in the game in the order they play, with the first player being the current player
 * @param tileDecks The decks of tiles available to the players
 * @param tileToPlace The tile to place on the board, or null if no tile is currently being placed
 * @param board The board containing the tiles and occupants placed on it
 * @param nextAction The next action to be taken by the current player
 * @param messageBoard The message board containing the messages displayed to the players up to this point
 * @author Antoine Bastide (375407)
 * @author Adam Bekkar (379476)
 */
public record GameState(List<PlayerColor> players, TileDecks tileDecks, Tile tileToPlace,
                        Board board, Action nextAction, MessageBoard messageBoard) {
    /**
     * Used to construct a game state
     * @param players The list of players in the game in the order they play,
     *                with the first player being the current player
     * @param tileDecks The decks of tiles available to the players
     * @param tileToPlace The tile to place on the board, or null if no tile is currently being placed
     * @param board The board containing the tiles and occupants placed on it
     * @param nextAction The next action to be taken by the current player
     * @param messageBoard The message board containing the messages displayed to the players up to this point
     */
    public GameState {
        Preconditions.checkArgument(players.size() > 1);
        Preconditions.checkArgument(Objects.isNull(tileToPlace) ^ nextAction == Action.PLACE_TILE);
        Preconditions.checkArgument(Objects.nonNull(tileDecks) && Objects.nonNull(board)
                && Objects.nonNull(nextAction) && Objects.nonNull(messageBoard));
        players = List.copyOf(players);
    }

    /** The enum that represents the next action to be taken by the current player */
    public enum Action { START_GAME, PLACE_TILE, OCCUPY_TILE, RETAKE_PAWN, END_GAME }

    /**
     * Used to get the initial state of the game
     * @param players The list of players in the game in the order they play,
     *                with the first player being the current player
     * @param tileDecks The decks of tiles available to the players
     * @param textMaker The text maker used to generate the messages
     * @return The initial state of the game
     */
    public static GameState initial(List<PlayerColor> players, TileDecks tileDecks, TextMaker textMaker) {
        return new GameState(players, tileDecks, null, Board.EMPTY,
                Action.START_GAME, new MessageBoard(textMaker, List.of()));
    }

    /**
     * Used to get the player that is currently playing
     * @return The player that is currently playing, or null if the next action is START_GAME or END_GAME
     */
    public PlayerColor currentPlayer() {
        return nextAction() == Action.START_GAME || nextAction() == Action.END_GAME ? null : players().getFirst();
    }

    /**
     * Used to get the number of free occupants of a given kind that a player can place on the board
     * @param player The player for which to get the number of free occupants
     * @param kind The kind of occupant for which to get the number of free occupants
     * @return The number of free occupants of the given kind that the player can place on the board
     */
    public int freeOccupantsCount(PlayerColor player, Occupant.Kind kind) {
        return Occupant.occupantsCount(kind) - board().occupantCount(player, kind);
    }

    /**
     * <b><i>Private method</i></b>
     * <p>Used to check if no pawn is occupying a given zone
     * @param zone The zone to check if it is unoccupied by a pawn
     * @return True if no pawn is occupying the zone, false otherwise
     */

    private boolean isUnoccupiedByPawn(Zone zone) {
        return (zone instanceof Zone.Meadow meadow && !board().meadowArea(meadow).isOccupied())
                || (zone instanceof Zone.River river && !board().riverArea(river).isOccupied())
                || (zone instanceof Zone.Forest forest && !board().forestArea(forest).isOccupied());
    }

    /**
     * Used to get the set of potential occupants of the last placed tile
     * @return The set of potential occupants of the last placed tile
     * @throws IllegalArgumentException If no tile has been placed yet
     */
    public Set<Occupant> lastTilePotentialOccupants() {
        PlacedTile placedTile = board().lastPlacedTile();
        Preconditions.checkArgument(Objects.nonNull(placedTile));

        // If the last placed tile has already an occupant return an empty set
        if (Objects.isNull(board().lastPlacedTile()) || Objects.nonNull(board().lastPlacedTile().occupant()))
            return Set.of();

        Set<Occupant> occupants = new HashSet<>();
        for (Occupant o : placedTile.potentialOccupants()) {
            // Check if the player has any free occupant of the given kind
            if (freeOccupantsCount(currentPlayer(), o.kind()) == 0) continue;
            PlacedTile tile = board().tileWithId(Zone.tileId(o.zoneId()));

            // If the zone is unoccupied, add the occupant to the set
            for (Zone zone : tile.tile().zones()) {
                boolean canOccupyByPawn = o.kind() == Occupant.Kind.PAWN
                        && freeOccupantsCount(currentPlayer(), Occupant.Kind.PAWN) > 0 && isUnoccupiedByPawn(zone);
                boolean canOccupyByHut = o.kind() == Occupant.Kind.HUT
                        && freeOccupantsCount(currentPlayer(), Occupant.Kind.HUT) > 0
                        && zone instanceof Zone.Water water && !board().riverSystemArea(water).isOccupied();
                if (canOccupyByPawn || canOccupyByHut) {
                    occupants.add(o);
                    break;
                }
            }
        }

        return Set.copyOf(occupants);
    }

    /**
     * Used to place the starting tile of the game on the board and start the game
     * @return The new state of the game with the starting tile placed
     * @throws IllegalArgumentException If the next action is not START_GAME
     */
    public GameState withStartingTilePlaced() {
        Preconditions.checkArgument(nextAction() == Action.START_GAME);
        Board newBoard = board().withNewTile(new PlacedTile(tileDecks().topTile(Tile.Kind.START), null,
                Rotation.NONE, Pos.ORIGIN));
        return new GameState(players(), tileDecks().withTopTileDrawn(Tile.Kind.START).withTopTileDrawn(Tile.Kind.NORMAL),
                tileDecks().topTile(Tile.Kind.NORMAL), newBoard, Action.PLACE_TILE, messageBoard());
    }

    /**
     * Used to place a tile on the board
     * @param placedTile The tile to place on the board
     * @return The new state of the game with the tile placed
     * @throws IllegalArgumentException If the next action is not PLACE_TILE
     */
    public GameState withPlacedTile(PlacedTile placedTile) {
        Preconditions.checkArgument(nextAction() == Action.PLACE_TILE
                && Objects.isNull(placedTile.occupant()));

        // Update the board, the message board and the tile decks
        Board newBoard = board().withNewTile(placedTile);
        MessageBoard newMessageBoard = messageBoard();

        // Check if the placed tile has special powers
        Zone spZone = placedTile.specialPowerZone();
        if (Objects.nonNull(spZone)) {
            switch (spZone.specialPower()) {
                // Score the log-boat
                case LOGBOAT -> newMessageBoard = newMessageBoard.withScoredLogboat(currentPlayer(),
                        newBoard.riverSystemArea((Zone.Water) spZone));
                // Score the hunting trap and remove the animals
                case HUNTING_TRAP -> {
                    // Find the meadows adjacent to the meadow where the hunting trap is placed and the animals in them
                    Area<Zone.Meadow> adjacentMeadows = newBoard.adjacentMeadow(placedTile.pos(), (Zone.Meadow) spZone);
                    Set<Animal> animals = Area.animals(adjacentMeadows, newBoard.cancelledAnimals());
                    Set<Animal> animalsToCancel = animalsToCancel(adjacentMeadows, newBoard, false, null);

                    // Cancel the animals in the meadows and score the hunting trap
                    newBoard = newBoard.withMoreCancelledAnimals(animalsToCancel);
                    newMessageBoard = newMessageBoard.withScoredHuntingTrap(currentPlayer(), adjacentMeadows);
                    newBoard = newBoard.withMoreCancelledAnimals(animals);
                }
                case SHAMAN -> {
                    if (newBoard.occupantCount(currentPlayer(), Occupant.Kind.PAWN) > 0)
                        return new GameState(players(), tileDecks(), null, newBoard, Action.RETAKE_PAWN, newMessageBoard);
                }
            }
        }

        // A temporary gameState is created to call lastTilePotentialOccupants on an updated board
        GameState tempGameState = new GameState(players(), tileDecks(), placedTile.tile(),
                newBoard, Action.PLACE_TILE, newMessageBoard);
        // Check if the player can occupy a tile, or tally the points at the end of the turn if not
        if (!tempGameState.lastTilePotentialOccupants().isEmpty())
            return new GameState(players(), tileDecks(), null, newBoard, Action.OCCUPY_TILE, newMessageBoard);
        else return tallyTurnPoints(newBoard, newMessageBoard);
    }

    /**
     * Used to retake a pawn on the board
     * @param occupant The occupant to remove from the board
     * @return The new state of the game with the occupant removed
     * @throws IllegalArgumentException If the next action is not RETAKE_PAWN
     * or if the given occupant is neither null nor a pawn
     */
    public GameState withOccupantRemoved(Occupant occupant) {
        // Check the arguments and update the board
        Preconditions.checkArgument(nextAction() == Action.RETAKE_PAWN &&
                (Objects.isNull(occupant) || occupant.kind() == Occupant.Kind.PAWN));
        Board newBoard = Objects.nonNull(occupant) ? board().withoutOccupant(occupant) : board();

        // Check if the player can occupy a tile, or tally the points at the end of the turn
        if (!lastTilePotentialOccupants().isEmpty())
            return new GameState(players(), tileDecks(), null, newBoard, Action.OCCUPY_TILE, messageBoard());
        else return tallyTurnPoints(newBoard, messageBoard());
    }

    /**
     * Used to occupy a tile on the board
     * @param occupant The occupant to place on the board
     * @return The new state of the game with the occupant placed
     * @throws IllegalArgumentException If the next action is not OCCUPY_TILE
     */
    public GameState withNewOccupant(Occupant occupant) {
        Preconditions.checkArgument(nextAction() == Action.OCCUPY_TILE);
        return tallyTurnPoints(Objects.isNull(occupant) ? board() : board().withOccupant(occupant), messageBoard());
    }

    /**
     * <b><i>Private method</i></b>
     * <p>Used to check if a given tile has closed a menhir forest
     * @return True if the tile has closed a menhir forest, false otherwise
     */
    private boolean hasClosedMenhirForest(Board newBoard, TileDecks newTileDecks) {
        Set<Area<Zone.Forest>> closedForests = newBoard.forestsClosedByLastTile();
        PlacedTile placedTile = newBoard.lastPlacedTile();
        return Objects.nonNull(placedTile) && placedTile.kind() == Tile.Kind.NORMAL
                && newTileDecks.deckSize(Tile.Kind.MENHIR) > 0
                && !closedForests.isEmpty() && closedForests.stream().anyMatch(Area::hasMenhir);
    }

    /**
     * <b><i>Private method</i></b>
     * <p>Used to cancel the animals in a meadow area
     * @param meadowArea The meadow area in which to cancel the animals
     * @param newBoard The current state of the board
     * @param hasWildFire True if the meadow area has a wildfire, false otherwise
     * @return The set of animals to cancel in the meadow area
     */
    private Set<Animal> animalsToCancel(Area<Zone.Meadow> meadowArea, Board newBoard, boolean hasWildFire, Zone.Meadow pitTrapZone) {
        // Make sur there are animals in the meadow
        Set<Animal> animals = Area.animals(meadowArea, newBoard.cancelledAnimals());
        if (animals.isEmpty()) return Set.of();

        // Count all the deer and tigers in the meadows
        int tigerCount = (int) animals.stream()
                .filter(animal -> animal.kind() == Animal.Kind.TIGER)
                .count();
        int deerCount = (int) animals.stream()
                .filter(animal -> animal.kind() == Animal.Kind.DEER)
                .count();

        // Find all the tigers
        Set<Animal> animalsToCancel = animals.stream()
                .filter(a -> a.kind() == Animal.Kind.TIGER)
                .collect(Collectors.toSet());
        // If there are no deer or if the meadow has a wildfire, cancel all the tigers
        if (tigerCount > 0 && !hasWildFire && deerCount > 0) {
            // Find all the deer
            Set<Animal> deerToCancel = animals.stream()
                    .filter(a -> a.kind() == Animal.Kind.DEER)
                    .collect(Collectors.toSet());

            // Check for a pit trap
            if (Objects.nonNull(pitTrapZone) && deerCount >= tigerCount) {
                // Find the tile ids that are adjacent to the pit trap
                Pos pos = newBoard.tileWithId(Zone.tileId(pitTrapZone.id())).pos();
                Set<Zone.Meadow> adjacentZones = newBoard.adjacentMeadow(pos, pitTrapZone).zones();
                Set<Integer> tileIds = meadowArea.zones().stream()
                        .filter(zone -> !adjacentZones.contains(zone))
                        .map(Zone::tileId)
                        .collect(Collectors.toSet());

                // Find the deer to keep, i.e. the ones that are in the adjacent meadows
                // The number of deer to keep is deerCount - tigerCount, since deerCount >= tigerCount
                Set<Animal> deerToKeep = deerToCancel.stream()
                        .filter(d -> !tileIds.contains(d.tileId()))
                        .limit(deerCount - tigerCount)
                        .collect(Collectors.toSet());

                // Find the deer to remove
                deerToCancel.removeAll(deerToKeep);
            }

            // Remove the correct number of deer from the set of animals to cancel
            int limit = Math.min(tigerCount, deerCount);
            deerToCancel = deerToCancel.stream()
                    .limit(limit)
                    .collect(Collectors.toSet());
            animalsToCancel.addAll(deerToCancel);
        }

        return animalsToCancel;
    }

    /**
     * <b><i>Private method</i></b>
     * <p>Used to tally the immediate scores at the end of a player's turn and then
     * decide whether the game continues or not.
     * <ul><li>If so, decide whether the player plays a menhir tile or not, update the deck,
     * the next action and the board</li></ul>
     * <ul><li>Otherwise, call tallyFinalScores which will tally the final scores and end the game</li></ul>
     * @param newBoard The new state of the board
     * @param newMessageBoard The new state of the message board
     * @return The new state of the game after tallying the points
     * @apiNote We've chosen to create a single method tallyTurnPoints instead of the two advised methods
     *      * withTurnFinishedIfOccupationImpossible and withTurnFinished but the logic is the same.
     *      * This method is called after a player has placed a tile, occupied a tile (if possible)
     *      * or retaken a pawn (if possible).
     */
    private GameState tallyTurnPoints(Board newBoard, MessageBoard newMessageBoard) {
        TileDecks newTileDecks = tileDecks().withTopTileDrawnUntil(Tile.Kind.NORMAL, newBoard::couldPlaceTile)
                                          .withTopTileDrawnUntil(Tile.Kind.MENHIR, newBoard::couldPlaceTile);

        Set<Area<Zone.Forest>> lastClosedForests = newBoard.forestsClosedByLastTile();
        Set<Area<Zone.River>> lastClosedRivers = newBoard.riversClosedByLastTile();

        // Remove the gatherers and fishers from the closed forests and rivers
        if (!lastClosedForests.isEmpty() || !lastClosedRivers.isEmpty()) {
            // Check if the player has closed a forest
            for (Area<Zone.Forest> forestArea : lastClosedForests)
                newMessageBoard = newMessageBoard.withScoredForest(forestArea);
            // Check if the player has closed a river
            for (Area<Zone.River> riverArea : lastClosedRivers)
                newMessageBoard = newMessageBoard.withScoredRiver(riverArea);

            newBoard = newBoard.withoutGatherersOrFishersIn(lastClosedForests, lastClosedRivers);
        }
        // If the placed tile has closed a menhir forest, the player can place another tile
        boolean playerHasSecondTurn = false;
        if (hasClosedMenhirForest(newBoard, newTileDecks)) {
            // Assign the points to the player that has closed the menhir forest
            for (Area<Zone.Forest> forestArea : lastClosedForests)
                if (Area.hasMenhir(forestArea))
                    newMessageBoard = newMessageBoard.withClosedForestWithMenhir(currentPlayer(), forestArea);
            playerHasSecondTurn = true;
        }
        // If there are no more tiles, tally the final scores
        else if (newTileDecks.deckSize(Tile.Kind.NORMAL) == 0)
            return tallyFinalScores(newBoard, newMessageBoard, newTileDecks);

        // Prepare the next turn if the next action is PLACE_TILE
        return nextTurnIsPlaceTile(newBoard, newMessageBoard, newTileDecks, playerHasSecondTurn);
    }

    /**
     * <b><i>Private method</i></b>
     * <p>Used to prepare the next turn of the game when the next action is PLACE_TILE
     * @param newBoard The new state of the board
     * @param newMessageBoard The new state of the message board
     * @param newTileDecks The new state of the tile decks
     * @param playerHasSecondTurn True if the player has a second turn, false otherwise
     * @return The new state of the game after preparing the next turn when the next action is PLACE_TILE
     */
    private GameState nextTurnIsPlaceTile(Board newBoard, MessageBoard newMessageBoard,
                                          TileDecks newTileDecks, boolean playerHasSecondTurn) {
        Tile.Kind tileKind = playerHasSecondTurn ? Tile.Kind.MENHIR : Tile.Kind.NORMAL;
        Tile tile = newTileDecks.topTile(tileKind);
        newTileDecks = newTileDecks.withTopTileDrawn(tileKind);
        List<PlayerColor> newPlayers = new ArrayList<>(players());
        if (!playerHasSecondTurn) Collections.rotate(newPlayers, -1);

        return new GameState(newPlayers, newTileDecks, tile, newBoard, Action.PLACE_TILE, newMessageBoard);
    }

    /**
     * <b><i>Private method</i></b>
     * <p>Used to tally the final scores at the end of the game
     * @param newBoard The new state of the board
     * @param newMessageBoard The new state of the message board
     * @param newTileDecks The new state of the tile decks
     * @return The new state of the game after tallying the final scores
     */
    private GameState tallyFinalScores(Board newBoard, MessageBoard newMessageBoard, TileDecks newTileDecks) {
        // Tally the scores for the meadows
        for (Area<Zone.Meadow> meadowArea : newBoard.meadowAreas()) {
            // Check if the meadow has a wildfire or a pit trap
            boolean hasWildFire = meadowArea.zones().stream()
                    .anyMatch(zone -> zone.specialPower() == Zone.SpecialPower.WILD_FIRE);
            Zone.Meadow pitTrapZone = meadowArea.zones().stream()
                    .filter(zone -> zone.specialPower() == Zone.SpecialPower.PIT_TRAP)
                    .findFirst()
                    .orElse(null);

            // Find the animals to cancel in the meadow area and score the area
            Set<Animal> animalsToCancel = animalsToCancel(meadowArea, newBoard, hasWildFire, pitTrapZone);
            newBoard = newBoard.withMoreCancelledAnimals(animalsToCancel);
            newMessageBoard = newMessageBoard.withScoredMeadow(meadowArea, animalsToCancel);
            // Check if the meadow has a pit trap and score it
            if (Objects.nonNull(pitTrapZone)) {
                Area<Zone.Meadow> adjacentMeadow = newBoard.adjacentMeadow(
                        newBoard.tileWithId(Zone.tileId(pitTrapZone.id())).pos(), pitTrapZone
                );
                newMessageBoard = newMessageBoard.withScoredPitTrap(adjacentMeadow, newBoard.cancelledAnimals());
            }
        }

        // Tally the scores for the river systems
        for (Area<Zone.Water> riverSystemArea : newBoard.riverSystemAreas()) {
            boolean hasRaft = riverSystemArea.zones().stream()
                    .anyMatch(zone -> zone.specialPower() == Zone.SpecialPower.RAFT);
            if (hasRaft) newMessageBoard = newMessageBoard.withScoredRaft(riverSystemArea);
            newMessageBoard = newMessageBoard.withScoredRiverSystem(riverSystemArea);
        }

        // Find the winners of the game and add to the message board a message with the winners
        newMessageBoard = getWinnersMessage(newMessageBoard);
        return new GameState(players(), newTileDecks, null, newBoard, Action.END_GAME, newMessageBoard);
    }

    /**
     * <b><i>Private method</i></b>
     * <p>Used to get the message board with the winners of the game
     * @param newMessageBoard The new state of the message board
     * @return The message board with the winners of the game
     * @apiNote Used only in tallyFinalScores to tally the final scores and end the game
     */
    private MessageBoard getWinnersMessage(MessageBoard newMessageBoard) {
        Map<PlayerColor, Integer> results = newMessageBoard.points();
        int maxScore = results.values().stream().max(Integer::compare).orElseThrow();
        Set<PlayerColor> winners = results.entrySet().stream()
                .filter(e -> e.getValue() == maxScore)
                .map(Map.Entry::getKey)
                .collect(Collectors.toSet());
        return newMessageBoard.withWinners(winners, maxScore);
    }
}
