package ch.epfl.chacun.gui;

import ch.epfl.chacun.*;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.ScrollPane;
import javafx.scene.effect.Blend;
import javafx.scene.effect.BlendMode;
import javafx.scene.effect.ColorInput;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Represents the GUI for the board
 * @author Antoine Bastide (375407)
 */
public class BoardUI {
    /** The map containing all the previously generated images */
    private static final Map<Integer, Image> cachedImages = createEmptyImageMap();
    /** The map containing all the previously generated occupants */
    private static final Map<Occupant, Node> cachedOccupants = new HashMap<>();
    /** The map containing all the generated veils */
    private static final Map<Color, ColorInput> cachedVeilColors = createVeilColors();
    /** The map containing all the previously generated veils */
    private static final Map<Group, Blend> cachedVeils = new HashMap<>();

    /**
     * Used to create the empty image map
     * @return The map containing the empty image
     */
    private static Map<Integer, Image> createEmptyImageMap() {
        // Create the map and add the empty tile image to key -1
        Map<Integer, Image> map = new HashMap<>();
        WritableImage emptyTileImage = new WritableImage(1, 1);
        emptyTileImage.getPixelWriter().setColor(0, 0, Color.gray(0.98));
        map.put(-1, emptyTileImage);
        return map;
    }

    /**
     * Used to create the veil colors
     * @return The map containing all the veil colors
     */
    private static Map<Color, ColorInput> createVeilColors() {
        // Create the map and add all the colors of the players, black and white to it
        Map<Color, ColorInput> map = new HashMap<>();
        Set<Color> colors = PlayerColor.ALL.stream().map(ColorMap::fillColor).collect(Collectors.toSet());
        colors.addAll(Set.of(Color.BLACK, Color.WHITE));
        for (Color color : colors) {
            // Create a color input for each color, set its height and width and put it in the map
            ColorInput input = new ColorInput(0, 0, 1, 1, color);
            input.setWidth(ImageLoader.NORMAL_TILE_FIT_SIZE);
            input.setHeight(ImageLoader.NORMAL_TILE_FIT_SIZE);
            map.put(color, input);
        }
        return map;
    }

    /** Private constructor to prevent instantiation */
    private BoardUI() {}

    /**
     * Used to create the GUI for the board
     * @param reach The reach of the board
     * @param gameStateP The current game state
     * @param tileRotation The current tile rotation
     * @param visibleOccupants The visible occupants
     * @param tilesInEvidence The ids of the tiles in evidence
     * @param rotateTile The function to rotate the tile
     * @param placeTile The function to place the tile
     * @param selectOccupant The function to select an occupant
     * @return The GUI for the board
     */
    public static Node create(int reach, ObservableValue<GameState> gameStateP, ObservableValue<Rotation> tileRotation,
                              ObservableValue<Set<Occupant>> visibleOccupants,
                              ObservableValue<Set<Integer>> tilesInEvidence, Consumer<Rotation> rotateTile,
                              Consumer<Pos> placeTile, Consumer<Occupant> selectOccupant) {
        // Create the grid and scroll pane
        GridPane grid = new GridPane();
        ScrollPane scrollPane = new ScrollPane(grid);

        // Apply the stylesheet and ids
        scrollPane.getStylesheets().add("board.css");
        scrollPane.setId("board-scroll-pane");
        grid.setId("board-grid");

        // Create the groups for the tiles and occupants
        for (int i = -reach; i <= reach; i++) {
            for (int j = -reach; j <= reach; j++) {
                // Create the image view
                ImageView tileView = new ImageView();
                tileView.setFitWidth(ImageLoader.NORMAL_TILE_FIT_SIZE);
                tileView.setFitHeight(ImageLoader.NORMAL_TILE_FIT_SIZE);

                // Create the tile group and its position
                Group tileGroup = new Group(tileView);
                Pos pos = new Pos(i, j);

                // Create the observable values needed to create a cell
                ObservableValue<PlacedTile> placedTileP = gameStateP.map(s -> s.board().tileAt(pos));
                ObservableValue<Tile> tileP = gameStateP.map(GameState::tileToPlace);
                ObservableValue<Boolean> isInsertionPositionP = gameStateP.map(s ->
                                s.board().insertionPositions()).map(p -> p.contains(pos));
                ObservableValue<Boolean> hoverP = tileGroup.hoverProperty();

                // Create the cell data property
                ObjectBinding<CellData> cellDataP = Bindings.createObjectBinding(() -> {
                    // Create a variable of the value of the properties used inside the lambda
                    GameState gameStateV = gameStateP.getValue();
                    PlacedTile placedTileV = placedTileP.getValue();
                    Boolean isInsertionPositionV = isInsertionPositionP.getValue();
                    Set<Integer> tilesInEvidenceV = tilesInEvidence.getValue();
                    Rotation tileRotationV = tileRotation.getValue();
                    Boolean hoverV = hoverP.getValue();

                    // Create the helper variables
                    PlayerColor currentPlayer = gameStateV.currentPlayer();
                    boolean nextActionIsCorrect = gameStateV.nextAction() == GameState.Action.PLACE_TILE;
                    boolean groupHasTile = Objects.nonNull(placedTileV);

                    // Get the color of the cell data
                    Color color = Color.TRANSPARENT;
                    // If the tile is not in evidence, show it as black
                    if (!tilesInEvidenceV.isEmpty() && groupHasTile
                            && !tilesInEvidenceV.contains(placedTileV.id()))
                            color = Color.BLACK;
                    // If the group has no tile and is in the insertion positions, try and show the fringe
                    if (!groupHasTile && nextActionIsCorrect && isInsertionPositionV) {
                        // If the tile is not hovered show the fringe
                        if (!hoverV) color = ColorMap.fillColor(Objects.requireNonNull(currentPlayer));
                        // If the tile is hovered and cannot be placed, white it out
                        else {
                            PlacedTile pt = new PlacedTile(tileP.getValue(), currentPlayer, tileRotationV, pos);
                            color = gameStateV.board().canAddTile(pt) ? Color.TRANSPARENT : Color.WHITE;
                        }
                    }

                    // Find the image
                    Image image;
                    boolean correctVeil = color != Color.BLACK;
                    // Reset the tile view to the correct tile if needed
                    if (groupHasTile) image = cachedImages.computeIfAbsent(placedTileV.id(),
                                _ -> ImageLoader.normalImageForTile(placedTileV.tile()));
                    // Set the tile view to the next tile if needed
                    else if (tilesInEvidenceV.isEmpty() && nextActionIsCorrect && correctVeil && hoverV
                            && Objects.nonNull(tileP) && isInsertionPositionV)
                        image = cachedImages.computeIfAbsent(tileP.getValue().id(), _ ->
                                ImageLoader.normalImageForTile(tileP.getValue()));
                    // Reset the tile view to the empty tile if needed
                    else image = cachedImages.get(-1);

                    return new CellData(image, tileRotationV, color);
                }, placedTileP, tilesInEvidence, tileRotation, hoverP, isInsertionPositionP, tileP);

                // Bind the veil color
                tileGroup.effectProperty().bind(cellDataP.map(CellData::color).map(c -> c == Color.TRANSPARENT ? null :
                    cachedVeils.computeIfAbsent(tileGroup, _ -> {
                            Blend blend = new Blend(BlendMode.SRC_OVER);
                            blend.setOpacity(0.5);
                            blend.topInputProperty().bind(cellDataP.map(CellData::color).map(cachedVeilColors::get));
                            return blend;
                    })
                ));

                // Bind the image and rotation depending on the cell data
                tileView.imageProperty().bind(cellDataP.map(CellData::image));
                tileGroup.rotateProperty().bind(cellDataP.map(d -> d.rotation.degreesCW()));

                // Add a listener on the placed tile property to update the GUI if needed
                placedTileP.addListener((o, oldValue, newValue) -> {
                    if (Objects.isNull(newValue) || newValue.equals(oldValue)) return;

                    // Create the animal UI if needed
                    for (Zone.Meadow z : newValue.meadowZones())
                        for (Animal animal : z.animals()) {
                            ImageView animalView = animalNodeFunction(gameStateP, o, animal, tileGroup);
                            if (!tileGroup.getChildren().contains(animalView))
                                tileGroup.getChildren().add(animalView);
                        }

                    // Create the occupant UI if needed, and cache it
                    for (Occupant occupant : newValue.potentialOccupants())
                        cachedOccupants.computeIfAbsent(occupant, _ -> occupantNodeFunction(tileRotation,
                                visibleOccupants, selectOccupant, newValue, occupant, tileGroup));

                    // Unbind rotate property of the tile group
                    tileGroup.rotateProperty().unbind();
                });

                // Create the event handler if tile group is clicked on
                tileGroup.setOnMouseClicked(e -> {
                    // Check if we are in the right state to place the tile and if the position is valid
                    if (gameStateP.getValue().nextAction() != GameState.Action.PLACE_TILE ||
                            !gameStateP.getValue().board().insertionPositions().contains(pos) ||
                            !e.isStillSincePress())
                        return;

                    // Place the tile on left click and rotate it on right-click
                    if (e.getButton() == MouseButton.PRIMARY) placeTile.accept(pos);
                    else if (e.getButton() == MouseButton.SECONDARY) {
                        if (e.isAltDown()) rotateTile.accept(Rotation.RIGHT);
                        else rotateTile.accept(Rotation.LEFT);
                    }
                });

                // Add the tile group to the grid
                grid.add(tileGroup, i + reach, j + reach);
            }
        }

        // Center the scroll pane in the display and return it
        scrollPane.setHvalue(.5);
        scrollPane.setVvalue(.5);

        return scrollPane;
    }

    /**
     * Used to create the occupant node function
     * @param tileRotation The tile rotation property
     * @param visibleOccupants The visible property
     * @param selectOccupant The select occupant consumer
     * @param pt The new placed tile
     * @param occupant The occupant
     * @param tileGroup The tile group
     * @return the occupant node function
     */
    private static Node occupantNodeFunction(ObservableValue<Rotation> tileRotation,
                                                                 ObservableValue<Set<Occupant>> visibleOccupants,
                                                                 Consumer<Occupant> selectOccupant, PlacedTile pt,
                                                                 Occupant occupant, Group tileGroup) {
        // Create the occupant view
        Node occupantView = Icon.newFor(pt.placer(), occupant);
        occupantView.setId(STR."\{occupant.kind().toString().toLowerCase()}_\{occupant.zoneId()}");
        occupantView.setRotate(tileRotation.getValue().negated().degreesCW());

        // Handle the click event
        occupantView.setOnMouseClicked(e -> {
            if (e.getButton() == MouseButton.PRIMARY) selectOccupant.accept(occupant);
        });
        // Bind the rotate and visible properties of the occupant view
        occupantView.rotateProperty().bind(tileGroup.rotateProperty().negate());
        occupantView.visibleProperty().bind(visibleOccupants.map(s -> s.contains(occupant)));
        // Add the occupant view to the tile group and return it
        tileGroup.getChildren().add(occupantView);
        return occupantView;
    }

    /**
     * Used to create the animal node function
     * @param gameState The game state
     * @param pt The listener of the placed tile property of the tile group
     * @param animal The animal
     * @param tileGroup The tile group
     * @return The function to create the animal node
     */
    private static ImageView animalNodeFunction(ObservableValue<GameState> gameState,
                                                             ObservableValue<? extends PlacedTile> pt, Animal animal,
                                                             Group tileGroup) {
        // Create the image view and set its height and width
        ImageView imageView = new ImageView();
        imageView.setFitHeight(ImageLoader.MARKER_FIT_SIZE);
        imageView.setFitWidth(ImageLoader.MARKER_FIT_SIZE);

        // Set image view's id and its style class
        imageView.setId(STR."marker_\{animal.id()}");
        imageView.getStyleClass().add("marker");

        // Bind the visible property of the image view,
        // add it to the tile group and return it
        imageView.visibleProperty().bind(pt.map(_ ->
                gameState.getValue().board().cancelledAnimals().contains(animal)));
        tileGroup.getChildren().add(imageView);
        return imageView;
    }

    /**
     * Represents the data of a cell
     * @param image The image of the cell
     * @param rotation The rotation of the image
     * @param color The color of the cell
     */
    private record CellData(Image image, Rotation rotation, Color color) {}
}
