package ch.epfl.chacun.gui;

import ch.epfl.chacun.PlayerColor;
import javafx.scene.paint.Color;

/**
 * Used to map PlayerColor to javafx.scene.paint.Color
 * @author Antoine Bastide (375407)
 */
public class ColorMap {
    /** Private constructor to prevent instantiation */
    private ColorMap() {}

    /**
     * Used to get the fill javafx.scene.paint.Color from a PlayerColor
     * @param color The color of the player
     * @return The javafx.scene.paint.Color corresponding to the PlayerColor
     */
    public static Color fillColor(PlayerColor color) {
        return switch (color) {
            case RED -> Color.RED;
            case BLUE -> Color.BLUE;
            case GREEN -> Color.LIME;
            case YELLOW -> Color.YELLOW;
            case PURPLE -> Color.PURPLE;
        };
    }

    /**
     * Used to get the stroke javafx.scene.paint.Color from a PlayerColor
     * @param color The color of the player
     * @return The javafx.scene.paint.Color corresponding to the PlayerColor
     */
    public static Color strokeColor(PlayerColor color) {
        return switch (color) {
            case GREEN, YELLOW -> fillColor(color).deriveColor(0, 1, 0.6, 1);
            default -> Color.WHITE;
        };
    }
}
