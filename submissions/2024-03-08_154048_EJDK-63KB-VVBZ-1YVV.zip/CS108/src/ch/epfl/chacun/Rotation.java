package ch.epfl.chacun;

import java.util.List;

/**
 * Used to represent the different rotations in the game.
 * The rotations are None, Right, Half Turn and Left.
 * @author Adam BEKKAR (379476)
 */
public enum Rotation {
    NONE, RIGHT, HALF_TURN, LEFT;

    /** A list containing all the possible directions in an unmodifiable list */
    public static final List<Rotation> ALL = List.of(values());

    /** The number of possible rotations */
    public static final int COUNT = ALL.size();

    /**
     * Used to add two rotations together
     * @param that The rotation to add to our current rotation
     * @return The new rotation
     */
    public Rotation add(Rotation that) {
        return ALL.get((that.ordinal() + ordinal()) % COUNT);
    }

    /**
     * Used to negate a rotation
     * @return The negation of the current rotation
     */
    public Rotation negated() {
        return ALL.get((COUNT - ordinal()) % COUNT);
    }

    /**
     * Used to get the number of quarter turns clockwise
     * @return The number of quarter turns clockwise
     */
    public int quarterTurnsCW() {
        return ordinal();
    }

    /**
     * Used to get the number of degrees clockwise
     * @return The number of degrees clockwise
     */
    public int degreesCW() {
        // The number of degrees in a quarter turn
        final int quarterTurnDegrees = 90;
        return quarterTurnsCW() * quarterTurnDegrees;
    }
}