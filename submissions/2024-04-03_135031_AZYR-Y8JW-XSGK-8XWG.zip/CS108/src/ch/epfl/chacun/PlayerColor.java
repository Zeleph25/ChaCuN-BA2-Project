package ch.epfl.chacun;

import java.util.List;

/**
 * Used to represent the different colors of the players: Red, Blue, Green, Yellow and Purple
 * @author Antoine Bastide (375407)
 */
public enum PlayerColor {
    RED, BLUE, GREEN, YELLOW, PURPLE;

    /** An unmodifiable list containing all the possible colors */
    public static final List<PlayerColor> ALL = List.of(values());
}
