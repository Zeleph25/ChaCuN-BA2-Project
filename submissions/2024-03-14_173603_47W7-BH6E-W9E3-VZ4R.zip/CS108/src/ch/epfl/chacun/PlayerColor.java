package ch.epfl.chacun;

import java.util.List;

/**
 * Used to represent the different colors of the players in the game.
 * The colors are Red, Blue, Green, Yellow and Purple.
 * @author Antoine Bastide (375407)
 */
public enum PlayerColor {
    RED, BLUE, GREEN, YELLOW, PURPLE;

    /** A list containing all the possible colors in an unmodifiable list */
    public static final List<PlayerColor> ALL = List.of(values());
}
