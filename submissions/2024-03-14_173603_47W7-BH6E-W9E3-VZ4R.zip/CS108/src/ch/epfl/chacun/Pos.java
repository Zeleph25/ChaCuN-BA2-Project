package ch.epfl.chacun;

/**
 * Represents a position in the game.
 * @param x The x coordinate of the position
 * @param y The y coordinate of the position
 * @author Antoine Bastide (375407)
 */
public record Pos(int x, int y) {
    /** The origin of the position system */
    public static final Pos ORIGIN = new Pos(0, 0);

    /**
     * Used to get the position translated by the given amount.
     * @param dX The amount to translate on the x-axis
     * @param dY The amount to translate on the y-axis
     * @return The translated position
     */
    public Pos translated(int dX, int dY) {
        return new Pos(x + dX, y + dY);
    }

    /**
     * Used to get the neighbor of the origin in the given direction.
     * @param direction The direction of the neighbor
     * @return The neighbor of the origin in the given direction
     */
    public Pos neighbor(Direction direction) {
        return switch (direction) {
            case N -> new Pos(x, y - 1);
            case E -> new Pos(x + 1, y);
            case S -> new Pos(x, y + 1);
            case W -> new Pos(x - 1, y);
        };
    }
}
