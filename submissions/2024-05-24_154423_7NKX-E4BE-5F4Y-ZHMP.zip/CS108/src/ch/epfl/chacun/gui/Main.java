package ch.epfl.chacun.gui;

import ch.epfl.chacun.*;
import javafx.application.Application;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.*;
import java.util.function.Consumer;
import java.util.random.RandomGenerator;
import java.util.random.RandomGeneratorFactory;
import java.util.stream.Collectors;

/**
 * Represents the full game UI of the ChaCuN game
 * @author Adam BEKKAR (379476)
 * @author Antoine Bastide (375407)
 */
public class Main extends Application {
    /** The id of the seed parameter when no seed is given */
    private static final String NO_SEED = "no seed";
    /** The width of the window */
    public static final int WINDOW_WIDTH = 1440;
    /** The height of the window */
    public static final int WINDOW_HEIGHT = 1080;
    /** The title of the window */
    public static final String WINDOW_TITLE = "ChaCuN";

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Check the number of players
        List<String> players = getParameters().getUnnamed();
        Preconditions.checkArgument(2 <= players.size() && players.size() <= 5);

        // Check the seed parameter
        String param = getParameters().getNamed().getOrDefault("seed", NO_SEED);
        RandomGenerator random;
        if (param.equals(NO_SEED)) random = RandomGeneratorFactory.getDefault().create();
        else random = RandomGeneratorFactory.getDefault().create(Long.parseUnsignedLong(param));

        // Create the player map
        Map<PlayerColor, String> playerNames = new HashMap<>();
        for (int i = 0; i < players.size(); i++) playerNames.put(PlayerColor.ALL.get(i), players.get(i));
        List<PlayerColor> playerColors = playerNames.keySet().stream().sorted().toList();

        // Create the tile deck and shuffle the tiles
        List<Tile> tiles = new ArrayList<>(Tiles.SUB_TILES);
        Collections.shuffle(tiles, random);
        Map<Tile.Kind, List<Tile>> tilesByKind = tiles.stream().collect(Collectors.groupingBy(Tile::kind));
        TileDecks tileDecks = new TileDecks(
                tilesByKind.get(Tile.Kind.START),
                tilesByKind.get(Tile.Kind.NORMAL),
                tilesByKind.get(Tile.Kind.MENHIR)
        );

        // Create the text maker and the initial game state
        TextMaker textMaker = new TextMakerFr(playerNames);
        GameState initialGamestate = GameState.initial(playerColors, tileDecks, textMaker);

        // Create the game state property
        ObjectProperty<GameState> gameStateP = new SimpleObjectProperty<>(initialGamestate);
        // Create the tile to place rotation property
        ObjectProperty<Rotation> tileToPlaceRotationP = new SimpleObjectProperty<>(Rotation.NONE);
        // Create the highlighted tiles property
        ObjectProperty<Set<Integer>> highlightedTilesP = new SimpleObjectProperty<>(Set.of());
        // Create the actions UI dependencies
        ObjectProperty<List<String>> actionsP = new SimpleObjectProperty<>(new ArrayList<>());
        // Create the visible occupants observable value
        ObservableValue<Set<Occupant>> visibleOccupants = gameStateP.map(g -> {
            Set<Occupant> visibleOccupantsSet = new HashSet<>(g.board().occupants());
            // Add the potential occupants of the last tile placed
            if (g.nextAction() == GameState.Action.OCCUPY_TILE)
                visibleOccupantsSet.addAll(g.lastTilePotentialOccupants());
            return visibleOccupantsSet;
        });

        // Action handler
        Consumer<String> actionHandler = a -> {
            // Decode the action and apply it to the game state
            ActionEncoder.StateAction stateAction = ActionEncoder.decodeAndApply(gameStateP.getValue(), a);
            if (Objects.nonNull(stateAction)) {
                PlacedTile lastPlacedTile = stateAction.gameState().board().lastPlacedTile();
                if (Objects.nonNull(lastPlacedTile)) tileToPlaceRotationP.set(lastPlacedTile.rotation());
                List<String> newActions = new ArrayList<>(actionsP.get());
                newActions.add(a);
                actionsP.set(newActions);
                gameStateP.set(stateAction.gameState());
                tileToPlaceRotationP.set(Rotation.NONE);
            }
        };

        // Event handlers for the board UI
        Consumer<Pos> posConsumer = p -> {
            GameState gameStateV = gameStateP.getValue();
            // Find the tile to place and check if it can be placed
            PlacedTile placedTile = new PlacedTile(gameStateV.tileToPlace(),
                    gameStateV.currentPlayer(), tileToPlaceRotationP.getValue(), p);
            if (gameStateV.board().canAddTile(placedTile)) {
                actionHandler.accept(ActionEncoder.withPlacedTile(gameStateV, placedTile).action());
            }
        };

        Consumer<Occupant> occupantConsumer = o -> {
            GameState gameStateV = gameStateP.getValue();
            // Add the occupant to the board if the player can occupy the tile
            if (gameStateV.nextAction() == GameState.Action.OCCUPY_TILE
                    && !gameStateV.board().occupants().contains(o))
                actionHandler.accept(ActionEncoder.withNewOccupant(gameStateV, o).action());
            // Remove the occupant from the board if the player can retake a pawn
            else if (gameStateV.nextAction() == GameState.Action.RETAKE_PAWN) {
                boolean validOccupant = Objects.isNull(o) ||
                        (o.kind() == Occupant.Kind.PAWN && gameStateV.board().occupants().contains(o) &&
                        gameStateV.board().tileWithId(Zone.tileId(o.zoneId())).placer() == gameStateV.currentPlayer());
                if (validOccupant)
                    actionHandler.accept(ActionEncoder.withOccupantRemoved(gameStateV, o).action());
            }
        };

        Consumer<Rotation> rotationConsumer = r -> 
                tileToPlaceRotationP.setValue(tileToPlaceRotationP.getValue().add(r));

        // Create the board UI
        Node boardNode = BoardUI.create(Board.REACH, gameStateP, tileToPlaceRotationP, visibleOccupants,
                highlightedTilesP, rotationConsumer, posConsumer, occupantConsumer);

        // Create the deck UI dependencies
        ObservableValue<Tile> tile = gameStateP.map(GameState::tileToPlace);
        ObservableValue<Integer> normalCount = gameStateP.map(g -> g.tileDecks().normalTiles().size());
        ObservableValue<Integer> menhirCount = gameStateP.map(g -> g.tileDecks().menhirTiles().size());
        // Map the correct text to show depending on the next action
        ObservableValue<String> text = gameStateP.map(GameState::nextAction).map(action -> {
            if (action == GameState.Action.OCCUPY_TILE) return textMaker.clickToOccupy();
            else if (action == GameState.Action.RETAKE_PAWN) return textMaker.clickToUnoccupy();
            else return "";
        });

        // Create the message board UI
        ObservableValue<List<MessageBoard.Message>> messages = gameStateP.map(g -> g.messageBoard().messages());
        ObjectProperty<Set<Integer>> tileIds = new SimpleObjectProperty<>(Set.of());
        highlightedTilesP.bind(tileIds);

        // Create the UIs
        BorderPane playerUI = new BorderPane(PlayersUI.create(gameStateP, textMaker));
        BorderPane messageBoardUI = new BorderPane(MessageBoardUI.create(messages, tileIds));
        BorderPane decksUI = new BorderPane(DecksUI.create(tile, normalCount, menhirCount, text, occupantConsumer));
        BorderPane actionUI = new BorderPane(ActionsUI.create(actionsP, actionHandler));

        // Right-hand part of the GUI
        BorderPane right = new BorderPane();
        right.setTop(playerUI);
        right.setCenter(messageBoardUI);
        right.setBottom(new VBox(actionUI, decksUI));

        // The root of the scene graph
        BorderPane container = new BorderPane();
        container.setCenter(boardNode);
        container.setRight(right);

        // Create the scene
        primaryStage.setScene(new Scene(container));
        primaryStage.setTitle(WINDOW_TITLE);
        primaryStage.setWidth(WINDOW_WIDTH);
        primaryStage.setHeight(WINDOW_HEIGHT);
        primaryStage.show();

        // Start the game
        gameStateP.set(gameStateP.get().withStartingTilePlaced());
    }
}