package ch.epfl.chacun;

import java.util.*;

/**
 * Used to represent an area of the board
 * @param zones The zones that make up the area
 * @param occupants The players that have placed an occupant in the area
 * @param openConnections The number of open connections in the area
 * @param <Z> The generic type used to allow the area to contain different types of zones
 * @author Antoine Bastide (375407)
 */
public record Area<Z extends Zone>(Set<Z> zones, List<PlayerColor> occupants, int openConnections) {
    public Area {
        // Make sure the arguments are valid
        Preconditions.checkArgument(openConnections >= 0);
        zones = Set.copyOf(zones);
        occupants = new ArrayList<>(occupants);
        Collections.sort(occupants);
        occupants = List.copyOf(occupants);
    }

    /**
     * Used to check if a forest area has at least one menhir
     * @param forest The forest area to check
     * @return True if the area has at least one menhir, False otherwise
     */
    public static boolean hasMenhir(Area<Zone.Forest> forest) {
        for (Zone.Forest zone : forest.zones()) {
            if (zone.kind() == Zone.Forest.Kind.WITH_MENHIR) return true;
        }
        return false;
    }

    /**
     * Used to count the number of mushroom groups in a forest area
     * @param forest The forest area to check
     * @return The number of mushroom groups in the forest area
     */
    public static int mushroomGroupCount(Area<Zone.Forest> forest) {
        int mushroomGroupCount = 0;
        for (Zone.Forest zone : forest.zones()) {
            if (zone.kind() == Zone.Forest.Kind.WITH_MUSHROOMS) mushroomGroupCount++;
        }
        return mushroomGroupCount;
    }

    /**
     * Used to get all the animals in a meadow area that are not cancelled
     * @param meadow The meadow area to check
     * @param cancelledAnimals The animals that are cancelled out
     * @return The set of animals in the meadow that are not cancelled
     */
    public static Set<Animal> animals(Area<Zone.Meadow> meadow, Set<Animal> cancelledAnimals) {
        // Create the animal set and populate it with the animals in the meadow that are not cancelled
        Set<Animal> animals = new HashSet<>();
        for (Zone.Meadow zone : meadow.zones()) animals.addAll(zone.animals());
        animals.removeAll(cancelledAnimals);
        return animals;
    }

    /**
     * Used to count the number of fish in a river area
     * @param river The river area to check
     * @return The number of fish in the river area
     */
    public static int riverFishCount(Area<Zone.River> river) {
        int fishCount = 0;
        Set<Zone.Lake> previousLakes = new HashSet<>();
        for (Zone.River zone : river.zones()) {
            fishCount += zone.fishCount();
            if (zone.hasLake() && previousLakes.add(zone.lake())) fishCount += zone.lake().fishCount();
        }
        return fishCount;
    }

    /**
     * Used to count the number of fish in a river system area
     * @param riverSystem The river system area to check
     * @return The number of fish in the river system area
     */
    public static int riverSystemFishCount(Area<Zone.Water> riverSystem) {
        int fishCount = 0;
        Set<Zone.Lake> previousLakes = new HashSet<>();
        for (Zone.Water zone : riverSystem.zones()) {
            // If the zone is a river, add the fish in the river and the lake if it exists
            if (zone instanceof Zone.River river) {
                fishCount += zone.fishCount();
                if (river.hasLake() && previousLakes.add(river.lake())) fishCount += river.lake().fishCount();

            }
            else if (zone instanceof Zone.Lake lake) fishCount += previousLakes.add(lake) ? lake.fishCount() : 0;
        }
        return fishCount;
    }

    /**
     * Used to count the number of lakes in a river system area
     * @param riverSystem The river system area to check
     * @return The number of lakes in the river system area
     */
    public static int lakeCount(Area<Zone.Water> riverSystem) {
        Set<Zone.Lake> lakes = new HashSet<>();
        for (Zone.Water zone : riverSystem.zones()) {
            if (zone instanceof Zone.River river && river.hasLake()) lakes.add(river.lake());
            else if (zone instanceof Zone.Lake lake) lakes.add(lake);
        }
        return lakes.size();
    }

    /**
     * Used to check if this area is closed
     * @return True if the area is closed, False otherwise
     */
    public boolean isClosed() {
        return this.openConnections == 0;
    }

    /**
     * Used to check if this area is occupied
     * @return True if the area has at least one occupant, False otherwise
     */
    public boolean isOccupied() {
        return !this.occupants.isEmpty();
    }

    /**
     * Used to get the majority occupants of the area
     * @return The set of majority occupants of the area
     */
    public Set<PlayerColor> majorityOccupants() {
        if (!this.isOccupied()) return Set.of(); // If the area is not occupied by anyone, return an empty set

        // Count the number of occupants of each color
        int[] occupantCount = new int[PlayerColor.ALL.size()];
        for (PlayerColor occupant : this.occupants) ++occupantCount[occupant.ordinal()];
        // Find the majority occupants
        int maxOccupantCount = -1;
        for (int count : occupantCount) maxOccupantCount = Math.max(maxOccupantCount, count);
        // Add the majority occupants to the set
        Set<PlayerColor> majorityOccupants = new HashSet<>();
        for (PlayerColor occupant : PlayerColor.ALL) {
            if (occupantCount[occupant.ordinal()] == maxOccupantCount) majorityOccupants.add(occupant);
        }
        return majorityOccupants;
    }

    /**
     * Used to combine this area with another area
     * @param that The other area to combine with
     * @return The combination of both areas
     */
    public Area<Z> connectTo(Area<Z> that) {
        // If the areas are the same, return a new area with the same zones and occupants but with two less open connections
        if (this.equals(that)) return new Area<>(this.zones, this.occupants, this.openConnections - 2);
        // If they are not the same, combine the zones and occupants of the two areas
        Set<Z> newZones = new HashSet<>(this.zones) {{ addAll(that.zones); }};
        List<PlayerColor> newOccupants = new ArrayList<>(this.occupants) {{ addAll(that.occupants); }};
        // The new area will have two less open connections than the sum of the open connections of the two areas
        return new Area<>(newZones, newOccupants, this.openConnections + that.openConnections - 2);
    }

    /**
     * Used change the occupant of an empty area
     * @param occupant The occupant to add to the area
     * @return The same area but with the given occupant
     * @throws IllegalArgumentException if the area is already occupied
     */
    public Area<Z> withInitialOccupant(PlayerColor occupant) {
        Preconditions.checkArgument(!this.isOccupied());
        return new Area<>(this.zones, List.of(occupant), this.openConnections);
    }

    /**
     * Used to remove an occupant from this area
     * @param occupant The occupant to remove to the area
     * @return The same area but without the given occupant
     * @throws IllegalArgumentException if the given occupant is not in the area
     */
    public Area<Z> withoutOccupant(PlayerColor occupant) {
        Preconditions.checkArgument(this.occupants.contains(occupant));
        return new Area<>(this.zones, new ArrayList<>(this.occupants) {{ remove(occupant); }}, this.openConnections);
    }

    /**
     * Used to remove all occupants from this area
     * @return The same area but without any occupants
     */
    public Area<Z> withoutOccupants() {
        return new Area<>(this.zones, List.of(), this.openConnections);
    }

    /**
     * Used to get the ids of all the tiles that make up the area
     * @return The set of ids of all the tiles that make up the area
     */
    public Set<Integer> tileIds() {
        Set<Integer> tileIds = new HashSet<>();
        for (Zone zone : zones) tileIds.add(zone.tileId());
        return tileIds;
    }

    /**
     * Used to try and find a zone with the given special power in this area
     * @param specialPower The special power to find
     * @return The zone with the given special power, or null if there is none
     */
    public Zone zoneWithSpecialPower(Zone.SpecialPower specialPower) {
        for (Zone zone : zones) {
            if (zone.specialPower() == specialPower) return zone;
        }
        return null;
    }
}
