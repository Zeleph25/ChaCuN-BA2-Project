package ch.epfl.chacun;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Represents a zone partition of the game
 * @param areas The areas that make up this ZonePartition
 * @param <Z> The generic type used to allow the zone builder to contain different types of zones
 * @author Antoine Bastide (375407)
 */
public record ZonePartition<Z extends Zone>(Set<Area<Z>> areas) {
    /**
     * Constructor for ZonePartition
     * @param areas The areas that make up this zone partition
     */
    public ZonePartition(Set<Area<Z>> areas) {
        this.areas = Set.copyOf(areas);
    }

    /** Empty constructor */
    public ZonePartition() {
        this(Set.of());
    }

    /**
     * Used to get the area containing a zone
     * @param zone The zone to find the area for
     * @return The area containing the zone
     * @throws IllegalArgumentException if the zone is not in any area of the partition
     */
    public Area<Z> areaContaining(Z zone) {
        return areas.stream().filter(area -> area.zones().contains(zone)).findFirst().orElseThrow(IllegalArgumentException::new);
    }

    /**
     * A builder class used to dynamically create a ZoneBuilder object
     * @param <Z> The generic type used to allow the builder to contain different types of zones
     * @author Antoine Bastide (375407)
     */
    public final static class Builder<Z extends Zone> {
        /** All the areas contained in this builder object */
        private final Set<Area<Z>> areas;

        /**
         * Constructor for Builder
         * @param partition The ZonePartition we are basing this Builder on
         */
        public Builder(ZonePartition<Z> partition) {
            areas = new HashSet<>(partition.areas());
        }

        /**
         * Used to add a given zone to this Builder
         * @param zone The zone to add to this Builder
         * @param openConnections The amount of open connections the given zone has
         */
        public void addSingleton(Z zone, int openConnections) {
            areas.add(new Area<>(Set.of(zone), new ArrayList<>(), openConnections));
        }

        /**
         * Used to add a given initial occupant to a given zone of this Builder
         * @param zone The zone we want to populate with the given occupant
         * @param color The color of the occupant we want to add to the given zone
         * @throws IllegalArgumentException if the given zone is not in any area of the partition,
         * or if the given zone is already occupied
         */
        public void addInitialOccupant(Z zone, PlayerColor color) {
            for (Area<Z> area : areas) {
                // Check if the area is already occupied
                if (area.zones().contains(zone)) {
                    Preconditions.checkArgument(!area.isOccupied());
                    areas.add(area.withInitialOccupant(color));
                    areas.remove(area);
                    return;
                }
            }
            // The given zone is not in this Builder
            throw new IllegalArgumentException("Given zone does not belong to an area of this Builder");
        }

        /**
         * Used to remove a given occupant from a given zone in this Builder
         * @param zone The zone we want to remove an occupant from
         * @param color The occupant to remove
         * @throws IllegalArgumentException if the given zone is not in this Builder, or if the given occupant does not occupy the given zone
         */
        public void removeOccupant(Z zone, PlayerColor color) {
            for (Area<Z> area : areas) {
                if (area.zones().contains(zone) && area.isOccupied() && area.occupants().contains(color)) {
                    // Remove the occupant
                    areas.add(area.withoutOccupant(color));
                    areas.remove(area);
                    return;
                }
            }
            // The given zone is not in this Builder
            throw new IllegalArgumentException();
        }

        /**
         * Used to remove all the occupants from a given area of this Builder
         * @param area The area we want to rid occupants of
         * @throws IllegalArgumentException if the given area is not a part of this Builder
         */
        public void removeAllOccupantsOf(Area<Z> area) {
            Preconditions.checkArgument(areas.contains(area));
            for (Area<Z> a : areas) {
                if (area.equals(a)) {
                    areas.add(a.withoutOccupants());
                    areas.remove(a);
                    return;
                }
            }
        }

        /**
         * Used to connect two given zones in this Builder
         * @param zone1 The first zone to connect
         * @param zone2 The second zone to connect
         * @throws IllegalArgumentException if the given zones do not exist in this Builder
         */
        public void union(Z zone1, Z zone2) {
            // Find the areas the zones are connected to
            Area<Z> area1 = null;
            Area<Z> area2 = null;
            for (Area<Z> area : areas) {
                if (area1 != null && area2 != null) break;
                if (area.zones().contains(zone1) && area1 == null) area1 = area;
                if (area.zones().contains(zone2) && area2 == null) area2 = area;
            }
            // Check if they exist and merge them if they do
            Preconditions.checkArgument(area1 != null && area2 != null);
            areas.add(area1.connectTo(area2));
            areas.remove(area1);
            areas.remove(area2);
        }

        /**
         * Used to convert a ZoneBuilder.Builder to a ZoneBuilder
         * @return The converted ZoneBuilder
         */
        public ZonePartition<Z> build() {
            return new ZonePartition<>(areas);
        }
    }
}
