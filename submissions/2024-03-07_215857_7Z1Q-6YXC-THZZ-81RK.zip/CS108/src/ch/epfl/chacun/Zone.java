package ch.epfl.chacun;

import java.util.List;

/**
 * Interface to represent a zone in the game.
 * @author Adam BEKKAR (379476)
 */
public sealed interface Zone {
    /** The different special powers a zone can have */
    enum SpecialPower { SHAMAN, LOGBOAT, HUNTING_TRAP, PIT_TRAP, WILD_FIRE, RAFT }

    /**
     * Used to get the id of the tile where one zone is
     * @param zoneId the id of the zone
     * @return the id of the tile where the zone is
     */
    static int tileId(int zoneId) {
        return zoneId / 10;
    }

    /**
     * Used to get the local id of the zone in the tile from 0 to 9
     * @param zoneId the id of the zone
     * @return the local id of the zone
     */
    static int localId(int zoneId) {
        return zoneId % 10;
    }

    /** Used to get the id of this zone */
    int id();

    /**
     * Used to get the id of the tile where this zone is
     * @return the id of the tile where the zone is
     */
    default int tileId() {
        return tileId(id());
    }

    /**
     * Used to get the local id of this zone in the tile from 0 to 9
     * @return the local id of the zone
     */
    default int localId() {
        return localId(id());
    }

    /**
     * Used to get the special power of this zone
     * @return the special power of the zone
     */
    default SpecialPower specialPower() {
        return null;
    }

    /**
     * Record implementing the interface Zone to represent a forest zone
     * @param id the id of the zone
     * @param kind the kind of the forest
     */
    record Forest(int id, Kind kind) implements Zone {
        /** The different types of forests the game has */
        public enum Kind { PLAIN, WITH_MENHIR, WITH_MUSHROOMS }
    }

    /**
     * Record implementing the interface Zone that represents a meadow zone
     * @param id the id of the zone
     * @param animals the list of animals in the meadow
     * @param specialPower the special power of the meadow
     */
    record Meadow(int id, List<Animal> animals, SpecialPower specialPower) implements Zone {
        public Meadow {
            animals = List.copyOf(animals); // Defensive copy for immutability
        }
    }

    /** Interface extending Zone to represent a water zone */
    sealed interface Water extends Zone {
        /** Used to get the number of fish in the water zone */
        int fishCount();
    }

    /**
     * Record implementing the interface Zone.Water to represent a lake zone
     * @param id the id of the zone
     * @param fishCount the number of fish in the lake
     * @param specialPower the special power of the lake
     */
    record Lake(int id, int fishCount, SpecialPower specialPower) implements Zone.Water {}

    /**
     * Record implementing the interface Zone.Water to represent a river zone
     * @param id the id of the zone
     * @param fishCount the number of fish in the river
     * @param lake the lake where the river is connected to
     */
    record River(int id, int fishCount, Lake lake) implements Zone.Water {
        /**
         * Used to check if the river is connected to a lake
         * @return True if the river is connected to a lake, False otherwise
         */
        public boolean hasLake() {
            return lake != null;
        }
    }
}