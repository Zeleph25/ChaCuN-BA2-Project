package ch.epfl.chacun;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Represents a tile placed on the board.
 * @author Adam BEKKAR (379476)
 */
public record PlacedTile(Tile tile, PlayerColor placer, Rotation rotation, Pos pos, Occupant occupant) {
    /**
     * Constructor for a placed tile
     * @param tile The tile to place
     * @param placer The color of the player who placed the tile
     * @param rotation The rotation of the tile
     * @param pos The position of the tile
     * @param occupant The occupant of the tile
     */
    public PlacedTile {
        // Make sure the arguments are valid
        Objects.requireNonNull(tile, "The tile cannot be null");
        Objects.requireNonNull(rotation, "The rotation cannot be null");
        Objects.requireNonNull(pos, "The position cannot be null");
    }

    /**
     * Second constructor for a placed tile, with a null occupant
     * @param tile The tile to place
     * @param placer The color of the player who placed the tile
     * @param rotation The rotation of the tile
     * @param pos The position of the tile
     */
    public PlacedTile(Tile tile, PlayerColor placer, Rotation rotation, Pos pos) {
        this(tile, placer, rotation, pos, null);
    }

    /**
     * Used to get the id of the placed tile
     * @return the id of the placed tile
     */
    public int id() {
        return tile.id();
    }
    public Tile.Kind kind() {
        return tile.kind();
    }

    /**
     * Used to get the side of the tile in the given direction compared to the placed tile
     * @param direction The direction of the side we compare to the placed tile
     * @return the side of the tile in the given direction
     */
    public TileSide side(Direction direction) {
        return switch (direction.rotated(rotation.negated())) {
            case N -> tile.n();
            case E -> tile.e();
            case S -> tile.s();
            case W -> tile.w();
        };
    }

    /**
     * Used to get the zone of the placed tile with the given id
     * @return the zone of the placed tile with the given id
     * @throws IllegalArgumentException if the tile does not have a zone with the given id
     */
    public Zone zoneWithId(int id) {
        for (Zone zone : tile.zones()) {
            if (zone.localId() == id) return zone;
        }
        throw new IllegalArgumentException();
    }

    /**
     * Used to get the zone of the placed tile with special powers, or null if there is none
     * @return the zones of the placed tile with special powers
     */
    public Zone specialPowerZone() {
        Zone specialZone = null;
        for (Zone zone1 : tile.zones()) {
            if (zone1.specialPower() != null) specialZone = zone1;
        }
        return specialZone;
    }

    /**
     * Used to get the zones of the placed tile that are forests
     * @return the zones of the placed tile that are forests
     */
    public Set<Zone.Forest> forestZones() {
        Set<Zone.Forest> forestSet = new HashSet<>();
        for (Zone zone : tile.zones()) {
            if (zone instanceof Zone.Forest) {
                forestSet.add((Zone.Forest) zone);
            }
        }
        return forestSet;
    }

    /**
     * Used to get the zones of the placed tile that are forests
     * @return the zones of the placed tile that are forests
     */
    public Set<Zone.Meadow> meadowZones() {
        Set<Zone.Meadow> meadowSet = new HashSet<>();
        for (Zone zone : tile.zones()) {
            if (zone instanceof Zone.Meadow) {
                meadowSet.add((Zone.Meadow) zone);
            }
        }
        return meadowSet;
    }

    /**
     * Used to get the zones of the placed tile that are forests
     * @return the zones of the placed tile that are forests
     */
    public Set<Zone.River> riverZones() {
        Set<Zone.River> riverSet = new HashSet<>();
        for (Zone zone : tile.zones()) {
            if (zone instanceof Zone.River) {
                riverSet.add((Zone.River) zone);
            }
        }
        return riverSet;
    }

    /**
     * Used to get the potential occupants of the zones of the placed tile
     * @return the potential occupants of the zones of the placed tile
     */
    public Set<Occupant> potentialOccupants() {
        if (placer == null) return Set.of();
        else {
            Set<Occupant> potentialOccupants = new HashSet<>();
            for (Zone zone : tile.zones()) {
                // Check the side zones
                if (tile.sideZones().contains(zone)) potentialOccupants.add(new Occupant(Occupant.Kind.PAWN, zone.id()));
                // Check the special requirements for the water zones
                if (zone instanceof Zone.River river && !river.hasLake()) potentialOccupants.add(new Occupant(Occupant.Kind.HUT, river.lake().id()));
                else if (zone instanceof Zone.Lake) potentialOccupants.add(new Occupant(Occupant.Kind.HUT, zone.id()));
            }
            return potentialOccupants;
        }
    }

    /**
     * Used to get the same placed tile but with the given occupant
     * @return the same placed tile but with the given occupant
     * @throws IllegalArgumentException if the tile is already occupied
     */
    public PlacedTile withOccupant(Occupant occupant) {
        Preconditions.checkArgument(this.occupant == null);
        return new PlacedTile(tile, placer, rotation, pos, occupant);
    }

    /**
     * Used to get the same placed tile but with no occupant
     * @return the same placed tile but with no occupant
     */
    public PlacedTile withNoOccupant() {
        return new PlacedTile(tile, placer, rotation, pos);
    }

    /**
     * Used to get the id of the zone occupied by the given kind of occupant, or -1 if there is none
     * @param occupantKind the kind of the occupant
     * @return the id of the zone occupied by the given kind of occupant, or -1 if there is none
     */
    public int idOfZoneOccupiedBy(Occupant.Kind occupantKind) {
        if (occupant == null || occupantKind != occupant.kind()) return -1;
        else return occupant.zoneId();
    }
}